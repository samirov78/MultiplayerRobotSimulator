//
//  TutoXmlParseur.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-11.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
//
//  ParseurXmlReglages.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-04.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import Foundation
import AEXML

class TutoXmlParseur :NSObject, XMLParserDelegate, FileManagerDelegate {
    
    var parseurXml = XMLParser()
    var dejaVu = false
    //var nomCarte = ""
    
    func chargerXML(){
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Tutoriel")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let pathCourant = documentDirectory.appendingPathComponent("/Tutoriel/tuto.xml")
        print(pathCourant)
        let fileManager = FileManager.default
        
        if fileManager.fileExists(atPath: pathCourant){
            var dataBuffer = fileManager.contents(atPath: pathCourant)
            dataBuffer = NSData(contentsOfFile: pathCourant) as Data?
            
            self.parseurXml = XMLParser(data: dataBuffer!)
            self.parseurXml.delegate = self
            self.parseurXml.parse()
            
            
        }else{
            print("file not found")
        }
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        switch elementName {
            
        case "Tutoriel":
            
            break
            
        case "DejaVu":
            
            let visionne = attributeDict["visionne"] as String!
            if(visionne == "false"){
                dejaVu = false
            } else {
                dejaVu = true
            }
            
            break
            
        default:
            
            break
            
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?){
        
        
    }
    
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Parseur XML : Une erreur est survenue")
    }
}
