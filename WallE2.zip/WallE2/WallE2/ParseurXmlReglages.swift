//
//  ParseurXmlReglages.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-04.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import Foundation
import AEXML

class ParseurXmlReglages :NSObject, XMLParserDelegate, FileManagerDelegate {
    
    var parseurXml = XMLParser()
    var mesReglages = Reglages()
    
    func chargerXML(){
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Reglages")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let pathCourant = documentDirectory.appendingPathComponent("/Reglages/reglages.xml")
        print(pathCourant)
        let fileManager = FileManager.default
        
        if fileManager.fileExists(atPath: pathCourant){
            var dataBuffer = fileManager.contents(atPath: pathCourant)
            dataBuffer = NSData(contentsOfFile: pathCourant) as Data?
            
            self.parseurXml = XMLParser(data: dataBuffer!)
            self.parseurXml.delegate = self
            self.parseurXml.parse()
            
            
        }else{
            print("file not found")
        }
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        switch elementName {
            
        case "Reglages":
            
            break
            
        case "Couleur":
            
            let couleur = attributeDict["name"] as String!
            let red = attributeDict["red"] as String!
            let green = attributeDict["green"] as String!
            let blue = attributeDict["blue"] as String!
            
            mesReglages.couleurChoisie = couleur!
            mesReglages.red = CGFloat(Float(red!)!)
            mesReglages.blue = CGFloat(Float(blue!)!)
            mesReglages.green = CGFloat(Float(green!)!)
            
            
            break
            
        case "Effet":
            
            let son = attributeDict["son"] as String!
            
            if(son == "false"){
                mesReglages.son = false
            } else {
                mesReglages.son = true
            }
        
            
            break
            
        case "Presentation":
            
            let presentation = attributeDict["forme"] as String!
            
            mesReglages.presentation = presentation!
            
            break
            
        case "Intensite":
            
            
            let alpha = attributeDict["alpha"] as String!
            
            mesReglages.alpha = CGFloat(Float(alpha!)!)
            
            break
            
        default:
            
            break
            
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?){
        
        
    }
    
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Parseur XML : Une erreur est survenue")
    }
}
