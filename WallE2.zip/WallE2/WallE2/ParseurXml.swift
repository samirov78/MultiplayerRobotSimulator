//
//  ParseurXml.swift
//  WallE2
//
//  Created by Morgane Renard on 17-03-26.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import AEXML

class ParseurXml :NSObject, XMLParserDelegate, FileManagerDelegate {
    
    var parseurXml = XMLParser()
    var mesObjetsCharges = [monObjetXML]()
    
    func chargerXML(nomFichier: String, path: String){
        let documentDirectory = path as NSString
        
        let pathCourant = documentDirectory.appendingPathComponent(nomFichier + ".xml")
        
        let fileManager = FileManager.default
        
        if fileManager.fileExists(atPath: pathCourant){
            var dataBuffer = fileManager.contents(atPath: pathCourant)
            dataBuffer = NSData(contentsOfFile: pathCourant) as Data?
            
            self.parseurXml = XMLParser(data: dataBuffer!)
            self.parseurXml.delegate = self
            self.parseurXml.parse()
            
            
        }else{
            print("file not found")
        }
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        switch elementName {
            
            case "xml":
                
                break
            
            case "configuration":
                
                break
            
            case "CScene":
                
                break
            
            case "ligne":
            
                break
            
            case "fleche":
    
                let id = attributeDict["ID"] as String!
                let type = attributeDict["Type"] as String!
                let affiche = attributeDict["Affiche"] as String!
                let enregistrable = attributeDict["Enregistrable"] as String!
                let selectionnable = attributeDict["Selectionnable"] as String!
                let angle = attributeDict["Angle"] as String!
                let x = attributeDict["x"] as String!
                let y = attributeDict["y"] as String!
                let z = attributeDict["z"] as String!
                let posX = attributeDict["Pos_x"] as String!
                let posY = attributeDict["Pos_y"] as String!
                let posZ = attributeDict["Pos_z"] as String!
                let redimX = attributeDict["Redim_x"] as String!
                let redimY = attributeDict["Redim_y"] as String!
                let redimZ = attributeDict["Redim_z"] as String!
                /*let departX = attributeDict["Depart_x"] as String!
                let departY = attributeDict["Depart_y"] as String!
                let departZ = attributeDict["Depart_z"] as String!
                let finX = attributeDict["Fin_x"] as String!
                let finY = attributeDict["Fin_y"] as String!
                let finZ = attributeDict["Fin_z"] as String!*/
                
                mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!)))
            
                /*mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!), departX: CGFloat(Float(departX!)!), departY: CGFloat(Float(departY!)!), departZ: CGFloat(Float(departZ!)!), finX: CGFloat(Float(finX!)!), finY: CGFloat(Float(finY!)!), finZ: CGFloat(Float(finZ!)!)))*/
                
                /*let Affiche = Int(affiche!)!
                let Enregistrable = Int(enregistrable!)!
                let Selectionnable = Int(selectionnable!)!
                let X = Int(x!)!
                let Y = Int(y!)!
                let Z = Int(z!)!
                
                let Angle = Float(angle!)
                let PosX = CGFloat(NumberFormatter().number(from: posX!)!)
                let PosY = CGFloat(NumberFormatter().number(from: posY!)!)
                let PosZ = CGFloat(NumberFormatter().number(from: posZ!)!)
                let RedimX = CGFloat(NumberFormatter().number(from: redimX!)!)
                let RedimY = CGFloat(NumberFormatter().number(from: redimY!)!)
                let RedimZ = CGFloat(NumberFormatter().number(from: redimZ!)!)
                let DepartX = CGFloat(NumberFormatter().number(from: departX!)!)
                let DepartY = CGFloat(NumberFormatter().number(from: departY!)!)
                let DepartZ = CGFloat(NumberFormatter().number(from: departZ!)!)
                let FinX = CGFloat(NumberFormatter().number(from: finX!)!)
                let FinY = CGFloat(NumberFormatter().number(from: finY!)!)
                let FinZ = CGFloat(NumberFormatter().number(from: finZ!)!)
                
                mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Affiche, enregistrable : Enregistrable, selectionnable : Selectionnable, angle: CGFloat(Angle!), x: X, y: Y, z: Z, posX: PosX, posY: PosY, posZ: PosZ, redimX: RedimX, redimY: RedimY, redimZ: RedimZ, departX: DepartX, departY: DepartY, departZ: DepartZ, finX: FinX, finY: FinY, finZ: FinZ))
                    
                mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!, enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(NumberFormatter().number(from: angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(NumberFormatter().number(from: posX!)!), posY: CGFloat(NumberFormatter().number(from: posY!)!), posZ: CGFloat(NumberFormatter().number(from: posZ!)!), redimX: CGFloat(NumberFormatter().number(from: redimX!)!), redimY: CGFloat(NumberFormatter().number(from: redimY!)!), redimZ: CGFloat(NumberFormatter().number(from: redimZ!)!), departX: CGFloat(NumberFormatter().number(from: departX!)!), departY: CGFloat(NumberFormatter().number(from: departY!)!), departZ: CGFloat(NumberFormatter().number(from: departZ!)!), finX: CGFloat(NumberFormatter().number(from: finX!)!), finY: CGFloat(NumberFormatter().number(from: finY!)!), finZ: CGFloat(NumberFormatter().number(from: finZ!)!)))*/
                
                break
            
            case "mur":
                
                let id = attributeDict["ID"] as String!
                let type = attributeDict["Type"] as String!
                let affiche = attributeDict["Affiche"] as String!
                let enregistrable = attributeDict["Enregistrable"] as String!
                let selectionnable = attributeDict["Selectionnable"] as String!
                let angle = attributeDict["Angle"] as String!
                let x = attributeDict["x"] as String!
                let y = attributeDict["y"] as String!
                let z = attributeDict["z"] as String!
                let posX = attributeDict["Pos_x"] as String!
                let posY = attributeDict["Pos_y"] as String!
                let posZ = attributeDict["Pos_z"] as String!
                let redimX = attributeDict["Redim_x"] as String!
                let redimY = attributeDict["Redim_y"] as String!
                let redimZ = attributeDict["Redim_z"] as String!
                /*let departX = attributeDict["Depart_x"] as String!
                let departY = attributeDict["Depart_y"] as String!
                let departZ = attributeDict["Depart_z"] as String!
                let finX = attributeDict["Fin_x"] as String!
                let finY = attributeDict["Fin_y"] as String!
                let finZ = attributeDict["Fin_z"] as String!*/
                
                mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!)))
                
                /*, departX: CGFloat(Float(departX!)!), departY: CGFloat(Float(departY!)!), departZ: CGFloat(Float(departZ!)!), finX: CGFloat(Float(finX!)!), finY: CGFloat(Float(finY!)!), finZ: CGFloat(Float(finZ!)!)))*/
                
                /*mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!, enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(NumberFormatter().number(from: angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(NumberFormatter().number(from: posX!)!), posY: CGFloat(NumberFormatter().number(from: posY!)!), posZ: CGFloat(NumberFormatter().number(from: posZ!)!), redimX: CGFloat(NumberFormatter().number(from: redimX!)!), redimY: CGFloat(NumberFormatter().number(from: redimY!)!), redimZ: CGFloat(NumberFormatter().number(from: redimZ!)!), departX: CGFloat(NumberFormatter().number(from: departX!)!), departY: CGFloat(NumberFormatter().number(from: departY!)!), departZ: CGFloat(NumberFormatter().number(from: departZ!)!), finX: CGFloat(NumberFormatter().number(from: finX!)!), finY: CGFloat(NumberFormatter().number(from: finY!)!), finZ: CGFloat(NumberFormatter().number(from: finZ!)!)))*/
                
                break
            
            case "segment":
            
                let id = attributeDict["ID"] as String!
                let type = attributeDict["Type"] as String!
                let affiche = attributeDict["Affiche"] as String!
                let enregistrable = attributeDict["Enregistrable"] as String!
                let selectionnable = attributeDict["Selectionnable"] as String!
                let angle = attributeDict["Angle"] as String!
                let x = attributeDict["x"] as String!
                let y = attributeDict["y"] as String!
                let z = attributeDict["z"] as String!
                let posX = attributeDict["Pos_x"] as String!
                let posY = attributeDict["Pos_y"] as String!
                let posZ = attributeDict["Pos_z"] as String!
                let redimX = attributeDict["Redim_x"] as String!
                let redimY = attributeDict["Redim_y"] as String!
                let redimZ = attributeDict["Redim_z"] as String!
                /*let departX = attributeDict["Depart_x"] as String!
                let departY = attributeDict["Depart_y"] as String!
                let departZ = attributeDict["Depart_z"] as String!
                let finX = attributeDict["Fin_x"] as String!
                let finY = attributeDict["Fin_y"] as String!
                let finZ = attributeDict["Fin_z"] as String!*/
                
                mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!)))
                
                /*mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!), departX: CGFloat(Float(departX!)!), departY: CGFloat(Float(departY!)!), departZ: CGFloat(Float(departZ!)!), finX: CGFloat(Float(finX!)!), finY: CGFloat(Float(finY!)!), finZ: CGFloat(Float(finZ!)!)))*/
                
                /*mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!, enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(NumberFormatter().number(from: angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(NumberFormatter().number(from: posX!)!), posY: CGFloat(NumberFormatter().number(from: posY!)!), posZ: CGFloat(NumberFormatter().number(from: posZ!)!), redimX: CGFloat(NumberFormatter().number(from: redimX!)!), redimY: CGFloat(NumberFormatter().number(from: redimY!)!), redimZ: CGFloat(NumberFormatter().number(from: redimZ!)!), departX: CGFloat(NumberFormatter().number(from: departX!)!), departY: CGFloat(NumberFormatter().number(from: departY!)!), departZ: CGFloat(NumberFormatter().number(from: departZ!)!), finX: CGFloat(NumberFormatter().number(from: finX!)!), finY: CGFloat(NumberFormatter().number(from: finY!)!), finZ: CGFloat(NumberFormatter().number(from: finZ!)!)))*/
            
                break
            
            case "poteau":
                
                let id = attributeDict["ID"] as String!
                let type = attributeDict["Type"] as String!
                let affiche = attributeDict["Affiche"] as String!
                let enregistrable = attributeDict["Enregistrable"] as String!
                let selectionnable = attributeDict["Selectionnable"] as String!
                let angle = attributeDict["Angle"] as String!
                let x = attributeDict["x"] as String!
                let y = attributeDict["y"] as String!
                let z = attributeDict["z"] as String!
                let posX = attributeDict["Pos_x"] as String!
                let posY = attributeDict["Pos_y"] as String!
                let posZ = attributeDict["Pos_z"] as String!
                let redimX = attributeDict["Redim_x"] as String!
                let redimY = attributeDict["Redim_y"] as String!
                let redimZ = attributeDict["Redim_z"] as String!
                /*let departX = attributeDict["Depart_x"] as String!
                let departY = attributeDict["Depart_y"] as String!
                let departZ = attributeDict["Depart_z"] as String!
                let finX = attributeDict["Fin_x"] as String!
                let finY = attributeDict["Fin_y"] as String!
                let finZ = attributeDict["Fin_z"] as String!*/
                
                mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!)))
                
                /*mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!,enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(Float(angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(Float(posX!)!), posY: CGFloat(Float(posY!)!), posZ: CGFloat(Float(posZ!)!), redimX: CGFloat(Float(redimX!)!), redimY: CGFloat(Float(redimY!)!), redimZ: CGFloat(Float(redimZ!)!), departX: CGFloat(Float(departX!)!), departY: CGFloat(Float(departY!)!), departZ: CGFloat(Float(departZ!)!), finX: CGFloat(Float(finX!)!), finY: CGFloat(Float(finY!)!), finZ: CGFloat(Float(finZ!)!)))*/
                
                /*mesObjetsCharges.append(monObjetXML(id: id!, type : type!, affiche: Int(affiche!)!, enregistrable : Int(enregistrable!)!, selectionnable : Int(selectionnable!)!, angle: CGFloat(NumberFormatter().number(from: angle!)!), x: Int(x!)!, y: Int(y!)!, z: Int(z!)!, posX: CGFloat(NumberFormatter().number(from: posX!)!), posY: CGFloat(NumberFormatter().number(from: posY!)!), posZ: CGFloat(NumberFormatter().number(from: posZ!)!), redimX: CGFloat(NumberFormatter().number(from: redimX!)!), redimY: CGFloat(NumberFormatter().number(from: redimY!)!), redimZ: CGFloat(NumberFormatter().number(from: redimZ!)!), departX: CGFloat(NumberFormatter().number(from: departX!)!), departY: CGFloat(NumberFormatter().number(from: departY!)!), departZ: CGFloat(NumberFormatter().number(from: departZ!)!), finX: CGFloat(NumberFormatter().number(from: finX!)!), finY: CGFloat(NumberFormatter().number(from: finY!)!), finZ: CGFloat(NumberFormatter().number(from: finZ!)!)))*/
                
                break
            

            default:
                
                break
            
        }
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?){
        
        
    }
    
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Parseur XML : Une erreur est survenue")
    }
    
    
}
