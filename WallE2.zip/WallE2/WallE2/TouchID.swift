//
//  TouchID.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-11.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import LocalAuthentication
import AEXML


class TouchID {
    
    var pasDeDevise = false;
    var loginProp = ""
    var motDePasseProp = ""
    var login = ""
    var motDePasse = ""
    var messageErreur = ""
    var profilXmlPath = ""
    var success = false
    var interface : String
    var termine = false
    init(interface: String){
        self.interface = interface
    }
    
    init(){
        self.interface = ""
    }
    
    // TouchID
    // Référence: https://the-nerd.be/2015/10/01/authentication-with-touchid/ (inspiration)
    
    func TouchID (){
    // 1. Create a authentication context
    let authenticationContext = LAContext()
    
    var error:NSError?
    
    // 2. Check if the device has a fingerprint sensor
    // If not, show the user an alert view and bail out!
    guard authenticationContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
        
        //showAlertViewIfNoBiometricSensorHasBeenDetected()
        pasDeDevise = true
        return
    }
    
    // 3. Check the fingerprint
    authenticationContext.evaluatePolicy(
        .deviceOwnerAuthenticationWithBiometrics,
        localizedReason: "Laissez votre doigt appuyé sur le bouton 'Home'",
        reply: { [unowned self] (success, error) -> Void in
            
            if( success ) {
                print("ici")
                // Fingerprint recognized
                // Go to view controller
                //self.navigateToAuthenticatedViewController()
                //print("réussi")
                /*self.motDePasse = "renardo"
                 self.identifiant = "momo"*/
                //self.motDePasse = "samir"
                //self.identifiant = "samir"
                /*DispatchQueue.main.async { () -> Void in
                    self.txtLogin.text = self.identifiant
                    //self.txtLogin.
                    self.txtPassWord.text = self.identifiant
                }
                self.matchTouchID = true*/
                    self.loginProp = self.login
                    self.motDePasseProp = self.motDePasse
                    self.enregisterID()

                //if(self.interface == "clavardage"){
                   // print("est ici")
                 //   self.success = true
                //}
                
            } else {
                
                // Check if there is an error
                if let error = error  {
                    let errorCode = (error as NSError).code
                    let message = self.errorMessageForLAErrorCode(errorCode: errorCode)
                    self.messageErreur = message
                    self.success = false
                    
                    //self.showAlertViewAfterEvaluatingPolicyWithMessage(message: message)
                    
                }
                
            }
            
        })
        
    }
    
    /*func showAlertViewAfterEvaluatingPolicyWithMessage( message:String ){
        
        showAlertWithTitle(title: "Error", message: message)
        
    }
    
    func showAlertViewIfNoBiometricSensorHasBeenDetected(){
        
        showAlertWithTitle(title: "Error", message: "This device does not have a TouchID sensor.")
        
    }
    
    func showAlertWithTitle( title:String, message:String ) {
        
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alertVC.addAction(okAction)
        
        DispatchQueue.main.async { () -> Void in
            
            self.present(alertVC, animated: true, completion: nil)
            
        }
        
    }*/
    
    func errorMessageForLAErrorCode( errorCode:Int ) -> String{
        
        var message = ""
        
        switch errorCode {
            
        case LAError.appCancel.rawValue:
            message = "Authentication was cancelled by application"
            
        case LAError.authenticationFailed.rawValue:
            message = "The user failed to provide valid credentials"
            
        case LAError.invalidContext.rawValue:
            message = "The context is invalid"
            
        case LAError.passcodeNotSet.rawValue:
            message = "Passcode is not set on the device"
            
        case LAError.systemCancel.rawValue:
            message = "Authentication was cancelled by the system"
            
            
        case LAError.touchIDLockout.rawValue:
            message = "Too many failed attempts."
            
        case LAError.touchIDNotAvailable.rawValue:
            message = "TouchID is not available on the device"
            //message = "TouchID n'est pas disponible sur ce périphérique"
            
        case LAError.userCancel.rawValue:
            message = "The user did cancel"
            //message = "L'utilisateur a annulé"
            
        case LAError.userFallback.rawValue:
            message = "The user chose to use the fallback"
        //message = "L'utilisateur a choisi de revenir en arrière"
        default:
            message = "Did not find error code on LAError object"
            //message = "Erreur inconnue"
            
        }
        
        return message
        
    }
    
    // Fin

    func recupererValeur(login: String, mdp: String){
        self.login = login
        self.motDePasse = mdp
    }
    
    func enregisterID(){
        //let fileManager = FileManager.default
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        //print(documentDirectory)
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Profil")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let nomXml = "/profil.xml"
        
        self.profilXmlPath = pathFileName + nomXml
        
        let sauvegarde = AEXMLDocument()
        let prop = sauvegarde.addChild(name: "Proprietaire")
        
        let attributsID = ["login" : "\(loginProp)", "motDePasse" : "\(motDePasseProp)"]
        prop.addChild(name: "Profil", attributes: attributsID)
        
        let xmlString = sauvegarde.xml
        do {
            
            _ = try xmlString.write(toFile: self.profilXmlPath, atomically: true, encoding: String.Encoding.utf8)
            
        }
        catch {
            print("\(error)")
        }

    }

}

class TouchIDXmlParseur :NSObject, XMLParserDelegate, FileManagerDelegate {
    
    var parseurXml = XMLParser()
    var touchID = TouchID()
    var mdp = ""
    var login = ""
    var existe = false
    
    func lancerTouchID(interface: String){
        touchID.interface = interface
        touchID.TouchID()
    }
    
    func chargerXML(){
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Profil")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let pathCourant = documentDirectory.appendingPathComponent("/Profil/profil.xml")
        print(pathCourant)
        let fileManager = FileManager.default
        
        if fileManager.fileExists(atPath: pathCourant){
            var dataBuffer = fileManager.contents(atPath: pathCourant)
            dataBuffer = NSData(contentsOfFile: pathCourant) as Data?
            
            self.parseurXml = XMLParser(data: dataBuffer!)
            self.parseurXml.delegate = self
            self.parseurXml.parse()
            
            existe = true
        }else{
            print("file not found")
            existe = false
        }
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        switch elementName {
            
        case "Proprietaire":
            
            break
            
        case "Profil":
            
            login = attributeDict["login"] as String!
            mdp = attributeDict["motDePasse"] as String!
            
            
            break
            
        default:
            
            break
            
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?){
        
        
    }
    
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Parseur XML : Une erreur est survenue")
    }
}
