//
//  GameScene.swift
//  WallE2
//
//  Created by Morgane Renard on 17-02-25.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import SpriteKit
import GameplayKit
import AEXML
import UIKit
import Foundation
import AudioToolbox


class monObjetXML {
    
    var noeud : SKSpriteNode!
    var id : String
    var type : String
    var affiche = 1
    var enregistrable = 1
    var selectionnable = 1
    var angle: CGFloat = 0
    var x: Int = 0
    var y: Int = 0
    var z: Int = 1
    var posX: CGFloat
    var posY: CGFloat
    var posZ: CGFloat
    var redimX: CGFloat
    var redimY: CGFloat
    var redimZ: CGFloat
    /*var departX: CGFloat
    var departY: CGFloat
    var departZ: CGFloat
    var finX: CGFloat
    var finY: CGFloat
    var finZ: CGFloat*/
    //var estModifie = false
    var ancienDepart = CGPoint(x: 0, y: 0)
    var ancienFin = CGPoint(x: 0, y: 0)
    
    init(noeud: SKSpriteNode){
        
        self.noeud = noeud
        id = NSUUID().uuidString
        type = noeud.name!
        angle = noeud.zRotation
        posX = noeud.position.x
        posY = noeud.position.y
        posZ = 1
        redimX = noeud.xScale
        redimY = noeud.yScale
        redimZ = 1
        /*departX = 0
        departY = 0
        departZ = 0
        finX = 0
        finY = 0
        finZ = 0*/
        
    }
    
    init (id: String, type : String, affiche: Int, enregistrable : Int, selectionnable : Int, angle: CGFloat, x: Int, y: Int, z: Int, posX: CGFloat, posY: CGFloat, posZ: CGFloat, redimX: CGFloat, redimY: CGFloat, redimZ: CGFloat) {
        
        // , departX: CGFloat, departY: CGFloat, departZ: CGFloat, finX: CGFloat, finY: CGFloat, finZ: CGFloat)
        
        self.id = id
        self.type = type
        self.affiche = affiche
        self.enregistrable = enregistrable
        self.selectionnable = selectionnable
        self.angle = angle
        self.x = x
        self.y = y
        self.z = z
        self.posX = posX
        self.posY = posY
        self.posZ = posZ
        self.redimX = redimX
        self.redimY = redimY
        self.redimZ = redimZ
        /*self.departX = departX
        self.departY = departY
        self.departZ = departZ
        self.finX = finX
        self.finY = finY
        self.finZ = finZ*/
    }
    
    func afficherAttributs(){
        print("id :", self.id)
        print("type :", self.type)
        print("angle :", self.angle)
        print("posX :", self.posX)
        print("posY :", self.posY)
        print("redimX :", self.redimX)
        print("redimY :", self.redimY)
        /*print("departX :", self.departX)
        print("departY :", self.departY)
        print("finX :", self.finX)
        print("finY :", self.finY)*/
    }
    
    
}

class Ligne {
    var lignes = [SKNode]()
    var nombreSegments: Int = 0
    var name :String = "ligne"
    
    init(){
        
    }
}

class ObjetAnnuler {
    var noeud: SKSpriteNode
    var angleRotation: CGFloat
    var position: CGPoint
    var scale: CGPoint
    
    init(noeud: SKSpriteNode, angle: CGFloat, scale: CGPoint, position: CGPoint){
        self.noeud = noeud
        self.angleRotation = angle
        self.scale = scale
        self.position = position
    }
    
    init(noeud: SKSpriteNode){
        self.noeud = noeud
        self.angleRotation = noeud.zRotation
        self.scale = CGPoint(x: noeud.xScale, y: noeud.yScale)
        self.position = noeud.position
    }

    
}

class monObjet {
    var noeud: SKSpriteNode
    var name :String
    var scale: CGFloat
    var posAvantScale: CGPoint
    
    
    init(noeud: SKSpriteNode){
        self.noeud = noeud
        scale = 5
        posAvantScale = CGPoint()
        name = noeud.name!
        
    }
    
}

extension CGPoint {
    ///Fonction calculant la distance entre deux points
    func distance(_ point: CGPoint) -> CGFloat {
        return abs(CGFloat(hypotf(Float(point.x - x), Float(point.y - y))))
    }
    
    ///Fonction calculant l'angle entre deux points
    func angle(_ point: CGPoint) -> CGFloat {
        return atan2(point.y - y, point.x - x)
    }
    
    ///Fonction retournant le point au centre de deux points
    func centre(_ point: CGPoint) -> CGPoint {
        return CGPoint(x: (point.x - x)/2 + x, y: (point.y - y)/2 + y)
    }
}


extension UIView {
    
    func screenShot() -> UIImage {
        UIGraphicsBeginImageContextWithOptions(bounds.size, false, UIScreen.main.scale)
        
        drawHierarchy(in: self.bounds, afterScreenUpdates: true)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}

class GameScene: SKScene {
    
    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    
    // Vue
    var viewController: UIViewController!
    
    private var lastUpdateTime : TimeInterval = 0
    private var label : SKLabelNode?
    //private var spinnyNode : SKShapeNode?
    
    private var xPremierClic: CGFloat = 0
    private var yPremierClic: CGFloat = 0
    private var xDernierClic: CGFloat = 0
    private var yDernierClic: CGFloat = 0
    
    // Variables table
    private var table : SKSpriteNode?
    private var positionScene = CGPoint(x: 0,y: 0)
    
    //private var table : SKNode?
    private var estSurLaTable = true
    
    // Gestures double tap
    private var doubleTap = false
    private var ajoute = false
    private var duplique = false
    
    // Variables poteau
    private var ajoutPoteau = false
    
    // Variables point de départ
    private var ajoutDepart = false
    private var counterDepart = 0
    
    // Variables ligne
    private var ajoutLigne = false
    private var boolLigne = false
    private var creationLigneF = false
    private var continuerLigne = false
    private var positionFinSegment = CGPoint(x: 0,y: 0)
    private var positionSegmentPrec = CGPoint(x: 0,y: 0)
    private var ensembleLignes = [Ligne]()
    private var indexLigne = 0
    private var ajoutLigneTermine = false
    //private var scaleDebut: CGFloat = 0
    
    // Variables mur
    private var ajoutMur = false
    private var boolMur = false
    private var creationMurF = false
    private var effaceMur = false
    
    // Variables sélection
    private var activeSelection = false
    private var noeud = SKSpriteNode()
    private var noeudSelectionne = [SKSpriteNode]()
    
    // Variables déplacement
    private var deplacement = false
    private var deplacementEnCours = false
    private var noeudPosition = [CGPoint]()
    //private var noeudPositionsAnciennes = [CGPoint]()
    private var annulerDeplacement = false
    //private var deplace = false
    
    // Variables duplication
    private var duplication = false
    private var duplicationEnCours = false
    private var annulerDeplacementDuplication = false
    private var etampe = [SKSpriteNode]()
    private var ancienneEtampe = [SKSpriteNode]()
    private var nbNoeudsDupliques = 0
    //private var nbTap = 0
    
    // Textures objets
    
    /*let tableTexture = SKTexture (imageNamed: "boisClair");
    
    // Table = 960 * 480 (*10)
    let tableTexture = SKTexture (imageNamed: "table");
    //let tableTexture = SKTexture (imageNamed: "tableCL");
    
    let poteauTexture = SKTexture (imageNamed: "poteauJaune");
    //let poteauTexture = SKTexture (imageNamed: "poteau");
    //let poteauTexture = SKTexture (imageNamed: "poteauCL");
    
    let murTexture = SKTexture (imageNamed: "petitMurBrique");
    //let murTexture = SKTexture (imageNamed: "mur");
    //let murTexture = SKTexture (imageNamed: "murCL");
    
    let ligneTexture = SKTexture (imageNamed: "CarreNoirMini")
    //let ligneTexture = SKTexture (imageNamed: "ligne")
    
    let departTexture = SKTexture (imageNamed: "departVertF");
    //let departTexture = SKTexture (imageNamed: "fleche");*/
    
    // Leger
    //let tableTexture = SKTexture (imageNamed: "tableLeger");
    let tableTexture = SKTexture (imageNamed: "table");
    let poteauTexture = SKTexture (imageNamed: "poteauLeger");
    let murTexture = SKTexture (imageNamed: "murLeger");
    let ligneTexture = SKTexture (imageNamed: "ligneLeger")
    let departTexture = SKTexture (imageNamed: "flecheLeger");
    
    // Barre de propriétes
    private var positionXProp:UITextField?
    private var positionYProp:UITextField?
    private var rotationProp:UITextField?
    private var echelleProp:UITextField?
    
    // Variables rotation
    private var activeRotation = false
    private var pointCentral = CGPoint(x: 0,y: 0)
    
    // Variables rotation (utiles pour sauvegarde et chargement)
    /*private var degreeRotation: CGFloat = 0
    private var centreRotation = CGPoint(x: 0,y: 0)
    private var indexDegreeObjet = 0
    private var tableauRotation = [ObjetRotation]()*/
   
    // Variables zoom
    var zoomActive = false
    var scaleActive = false
    var noeudSurTable = [monObjet]()
    var initialscaleTable :CGFloat = 1.0
    //var noeudScaleAncien = [CGPoint]()
    
    // Variable barre outils
    var barOutil = SKNode()
    private var boutonSupprimer = SKSpriteNode()
    
    // Variables déplacement de la vue
    var activeDeplacementVue = false
    var posInitiale: CGPoint?
    
    // Variables XML enregistrement
    var mesObjetsSauvegardes = [monObjetXML]()
    var imagePath = ""
    var xmlPath = ""
    
    // Variables XML chargement
    var nomCarte : String = ""
    var pathFichier : String = ""
    
    // Variables pour les effets sonores et réglages
    var alphaReglage: CGFloat = 1.0
    var sonActif = true
    var sonSupprimer :SystemSoundID = 0
    var sonAjouter :SystemSoundID = 0
    var sonSelectionner :SystemSoundID = 0
    var presentationListe = true
    
    //let murTexture = SKTexture (imageNamed: "petitMuretCompress");
    
    // Undo
    //var mesObjetsAnnules = [ObjetAnnuler]()
    var undoPossible = false
    var efface = false
    
    
    // TODO
    /************************************
 
    - Sauvegarde
    - Chargement
    
     
    PROBLEME A REGLER:
    - Position des objets lors du zoom et du déplacement de la vue (ajout et intérieur de la table) // fait pour l'ajout, demander au chargé pour l'intérieur de la table
    - Jonctions des lignes noires
    - Point de départ (gérer le compteur lors de la supression) // Fait
    - TextField: position lors du déplacement de la vue
    - Régler le doubleTap (pour éviter d'effecer le dernier point de départ)
    - Configuration des propriétés des objets individuels (régler un problème avec le facteur scale) // Parler avec Samie et groupe CL
    - Dimension table ATTENTION LA TABLE DOIT AVIR LES MEMES DIMENSIONS QUE CELLE DU CL
    
    ************************************/
    
    override func didMove(to view: SKView) {
        
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        doubleTap.numberOfTapsRequired = 2
        //vueCourante = (self.view?.window?.rootViewController)!
        view.addGestureRecognizer(doubleTap)
        //self.view?.addGestureRecognizer(tap)
        
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPressed))
        view.addGestureRecognizer(longGesture)
        
        /*let zoom = UIPinchGestureRecognizer(target: self, action: Selector(("ZoomInAndZoomOutObjet:")))*/
        
        let zoom = UIPinchGestureRecognizer(target: self, action: #selector (zoomer))
        self.view!.addGestureRecognizer(zoom)
        
        let rotationGesture = UIRotationGestureRecognizer(target: self, action: #selector(GameScene.rotation(_:)))
        self.view!.addGestureRecognizer(rotationGesture)
        
        
        //carte = Carte(nom: "NouvelleCarte")
        //print("nom de la carte: ", nomCarte)
        //print("path: ", pathFichier)
        
        if(!(nomCarte=="")){
            chargement()
        }
        let sonSuppression = Bundle.main.url(forResource: "firework", withExtension: "mp3")
        AudioServicesCreateSystemSoundID(sonSuppression! as CFURL, &sonSupprimer)
        let sonAjout = Bundle.main.url(forResource: "etabli", withExtension: "mp3")
        AudioServicesCreateSystemSoundID(sonAjout! as CFURL, &sonAjouter)
        let sonSelection = Bundle.main.url(forResource: "metal", withExtension: "mp3")
        AudioServicesCreateSystemSoundID(sonSelection! as CFURL, &sonSelectionner)
        view.alpha = alphaReglage
        initialiserTextField()
       
    }
    
    override func sceneDidLoad() {
        
        table?.removeFromParent()
        //table?.childNode(withName: "fleche")?.removeFromParent()
        table?.removeAllChildren()
        
        
        counterDepart = 0
        //barreDeProprietesActive(false)
        
        
        table = SKSpriteNode(texture: tableTexture)
        table?.name = "table"
        
        ajoutTable()
        
        toutSupprimer()
        //self.table = self.childNode(withName: "table") as? SKSpriteNode
       
        ajoutDepart(CGPoint(x: -200,y: -150))
        
        // Get label node from scene and store it for use later
        /*self.label = self.childNode(withName: "//helloLabel") as? SKLabelNode
        if let label = self.label {
            label.alpha = 0.0
            label.run(SKAction.fadeIn(withDuration: 2.0))
        }*/
        
        // Create shape node to use during mouse interaction
        /*let w = (self.size.width + self.size.height) * 0.05
        self.spinnyNode = SKShapeNode.init(rectOf: CGSize.init(width: w, height: w), cornerRadius: w * 0.3)
        
        if let spinnyNode = self.spinnyNode {
            spinnyNode.lineWidth = 2.5
            
            spinnyNode.run(SKAction.repeatForever(SKAction.rotate(byAngle: CGFloat(M_PI), duration: 1)))
            spinnyNode.run(SKAction.sequence([SKAction.wait(forDuration: 0.5),
                                              SKAction.fadeOut(withDuration: 0.5),
                                              SKAction.removeFromParent()]))
        }*/
        
        
       
        /*table?.xScale *= 0.6
        table?.yScale *= 0.6
        initialscaleTable = 0.6*/
        
    }
    
    func touchDown(atPoint pos : CGPoint) {
        /*if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.green
            self.addChild(n)
            
        }*/
        //print("position touche pos: ", pos)
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        /*if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.blue
            self.addChild(n)
        }*/
        /*if(boolMur){
            let positionX: CGFloat? = pos.x
            let positionY: CGFloat? = pos.y
            //var positionX: CGFloat? = 0
            //var positionY: CGFloat? = 0
            //positionX = t.location(in: table!).x
            //positionY = t.location(in: table!).y
            // var positionInitiale = CGPoint(x: xPremierClic,y: yPremierClic)
            //var positionXY = CGPoint(x: positionX!,y: positionY!)
            print("position x initiale : ", xPremierClic )
            print("position y initiale : ", yPremierClic )
            print("position x : ", positionX! )
            print("position y : ", positionY! )
            
            table!.children.last?.removeFromParent()
            let centreX = (positionX! + xPremierClic) / 2
            let centreY = (positionY! + yPremierClic) / 2
            let centre = CGPoint(x: centreX,y: centreY)
            //let longueur = sqrt(pow((positionX! - xPremierClic), 2) + pow((positionY! - yPremierClic), 2))
            let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/20
            //let longueur = positionInitiale.distance(positionXY)
            print("longueur : ", longueur )
            let angle: CGFloat? = atan((positionY! - yPremierClic)/(positionX! - xPremierClic))
            //let scale: CGFloat = 0.1
            //let scaleMur: CGFloat = (table!.childNode(withName: "mur")?.xScale)!
            //print("dans boucle")
            //(table!.childNode(withName: "mur"))?.setScale(scale + scaleMur)
            //(table!.childNode(withName: "mur"))?.xScale = scale + scaleMur
            ajoutMurFantome(centre, table!, longueur, angle!)
            //(table!.children.last)?.xScale = scale + scaleMur
            
        }*/
    }
    
    func touchUp(atPoint pos : CGPoint) {
        /*if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.red
            self.addChild(n)
        }*/
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        //Déplacement de la vue : l enregistrement de la position initiale
        posInitiale = touches.first!.location(in: self)
        
        if let label = self.label {
            label.run(SKAction.init(named: "Pulse")!, withKey: "fadeInOut")
            
            
        }
        
        for t in touches { self.touchDown(atPoint: t.location(in: self))
            positionScene =  t.location(in: self)
        }
        
        for tTable in touches { self.touchDown(atPoint: tTable.location(in: table!))
            
            
            let pos = tTable.location(in: table!)
            //print("position touche location in table: ", pos)
            /*print("position sur table : ", tTable.location(in: table!))
            if(ajoutPoteau){
            print("le poteau suivant est ajout avec position sur table")
            ajoutPoteau(tTable.location(in: table!))*/
                
                
                if(table!.frame.contains(self.convert(pos, from: table!))){
                    //mesObjetsAnnules.removeAll()
                    ajoute = false
                    duplique = false
                    //efface = false
                    
                    if(ajoutPoteau){
                        
                        //Pour faire l'ajout du poteau décommenter la ligne suivante
                        ajoutPoteau(pos)
                        ajoute = true
                        undoPossible = true
                        //let unId = NSUUID().uuidString
                        //print(unId)
                        
                    }
                    if(ajoutDepart){
                        ajoutDepart(pos)
                        ajoute = true
                        undoPossible = true
                    }
                    if(ajoutMur){
                        
                        xPremierClic = pos.x
                        yPremierClic = pos.y
                        
                        ajoutMur(pos)
                        ajoute = true
                        undoPossible = true
                        
                    }
                    if(ajoutLigne){
                        ajoute = true
                        undoPossible = true
                        if(!continuerLigne){
                            
                            xPremierClic = pos.x
                            yPremierClic = pos.y
                            ajoutSegmentLigneInit(pos)
                            //scaleDebut = (table!.children.last?.xScale)!
                            
                            // Pour lier les lignes
                            //let UneLigne = Ligne()
                            //ensembleLignes.append(UneLigne)
                        } else {
                            //let unePosition = CGPoint(x: positionFinSegment.x - scaleDebut/2, y: positionFinSegment.y)
                            positionSegmentPrec = positionFinSegment
                            xPremierClic = positionFinSegment.x
                            yPremierClic = positionFinSegment.y
                            ajoutSegmentLigneInit(positionFinSegment)
                            //ajoutSegmentLigneInit(unePosition, table!)
                            
                            
                        }
                    }
                    if(duplication){
                        xPremierClic = pos.x
                        yPremierClic = pos.y
                        dupliquer()
                        duplicationEnCours = true
                        duplique = true
                        undoPossible = true
                        //nbTap += 1
                        //print("nombre de tap ", nbTap)
                    }
                    
                }
                
                if(deplacement){
                    xPremierClic = pos.x
                    yPremierClic = pos.y
                    deplacementEnCours = true
                    //deplace = false
                    /*for noeud in noeudSelectionne{
                        mesObjetsAnnules.append(ObjetAnnuler(noeud: noeud))
                    }*/
                    //noeudPositionsAnciennes.removeAll()
                }

            }
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //print(boolMur)
        
        /*if(table!.children.contains(mur!)){
            mur!.xScale.add(2)
            print("dans boucle")
            //mur!.setScale(mur!.xScale.add(1))
        }*/
        for t in touches { self.touchMoved(toPoint: t.location(in: self))
            
                //if bool Mur
            if(boolMur /*&& estSurLaTable*/){
                //let positionX: CGFloat? = pos.x
                //let positionY: CGFloat? = pos.y
                //var positionX: CGFloat? = 0
                //var positionY: CGFloat? = 0
                let positionX: CGFloat? = t.location(in: table!).x
                let positionY: CGFloat? = t.location(in: table!).y
                // var positionInitiale = CGPoint(x: xPremierClic,y: yPremierClic)
                //var positionXY = CGPoint(x: positionX!,y: positionY!)
                /*print("position x initiale : ", xPremierClic )
                print("position y initiale : ", yPremierClic )
                print("position x : ", positionX! )
                print("position y : ", positionY! )*/
                //print(table!.children.last?.name)
                table!.children.last?.removeFromParent()
                let centreX = (positionX! + xPremierClic) / 2
                let centreY = (positionY! + yPremierClic) / 2
                let centre = CGPoint(x: centreX,y: centreY)
                
                //let longueur = sqrt(pow((positionX! - xPremierClic), 2) + pow((positionY! - yPremierClic), 2))
                
                // Pour texture petit mur brique
                
                //let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/33.3
                
                // Pour texture mur
                
                // let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/3
                
                // Pour texture murLeger
                
                let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/10
                
                // Pour texture mur CL
                
                /*let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/5*/
                
                //let longueur = positionInitiale.distance(positionXY)
                //print("longueur : ", longueur )
                let angle: CGFloat? = atan((positionY! - yPremierClic)/(positionX! - xPremierClic))
                //let scale: CGFloat = 0.1
                //let scaleMur: CGFloat = (table!.childNode(withName: "mur")?.xScale)!
                //print("dans boucle")
                //(table!.childNode(withName: "mur"))?.setScale(scale + scaleMur)
                //(table!.childNode(withName: "mur"))?.xScale = scale + scaleMur
                ajoutMurFantome(centre, longueur, angle!)
                //(table!.children.last)?.xScale = scale + scaleMur
                
                }
            // Fin if bool Mur
            if(boolLigne /*&& estSurLaTable*/){
                let positionX: CGFloat? = t.location(in: table!).x
                let positionY: CGFloat? = t.location(in: table!).y
                table!.children.last?.removeFromParent()
                let centreX = (positionX! + xPremierClic) / 2
                let centreY = (positionY! + yPremierClic) / 2
                let centre = CGPoint(x: centreX,y: centreY)
                //let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/20
                
                // Pour texture ligne
                
                // let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/8
                
                // Pour texture carré noir mini
                
                //let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/19
                
                // Pour texture ligneLeger
                
                let longueur = sqrt(((positionX! - xPremierClic)*(positionX! - xPremierClic))  + ((positionY! - yPremierClic)*(positionY! - yPremierClic)))/14.5
                
                let angle: CGFloat? = atan((positionY! - yPremierClic)/(positionX! - xPremierClic))
            
                ajoutSegmentLigneFantome(centre, longueur, angle!)
               
                
            }
            if(deplacementEnCours){
                let positionInitiale = CGPoint(x: xPremierClic,y: yPremierClic)
                //let positionActuelle = CGPoint(x: t.location(in: table!).x,y: t.location(in: table!).y)
                let positionActuelle = CGPoint(x: t.location(in: table!).x,y: t.location(in: table!).y)
                
                deplacerObjet(locationInit: positionInitiale, locationFinal: positionActuelle)
                verifierDeplacement()
                annulerDeplacement = false
                xPremierClic = positionActuelle.x
                yPremierClic = positionActuelle.y
                
            }
            if(duplicationEnCours){
                let positionInitiale = CGPoint(x: xPremierClic,y: yPremierClic)
                //let positionActuelle = CGPoint(x: t.location(in: table!).x,y: t.location(in: table!).y)
                let positionActuelle = CGPoint(x: t.location(in: self).x,y: t.location(in: self).y)
                deplacerEtampe(locationInit: positionInitiale, locationFinal: positionActuelle)
                verifierDuplication()
                annulerDeplacementDuplication = false
                xPremierClic = positionActuelle.x
                yPremierClic = positionActuelle.y
            }
        
            // Déplacement de la vue
            if activeDeplacementVue {
                // print("activer deplacement de la vue")
                /*let positionX: CGFloat? = t.location(in: self).x
                let positionY: CGFloat? = t.location(in: self).y
                let location1 = CGPoint(x: positionX!,y: positionY!)
                
                if (atPoint(location1) == table || atPoint(location1).name == "barre") {
                    
                    for node in self.children {
                        
                        if let noeud = node as? SKSpriteNode {
                            
                            
                            let offSetPosition = CGPoint(x: location1.x - posInitiale!.x,y:location1.y - posInitiale!.y)
                            
                            noeud.position.x += offSetPosition.x
                            noeud.position.y += offSetPosition.y
                        }
                    }
                    let offSetPosition = CGPoint(x: location1.x - posInitiale!.x,y:location1.y - posInitiale!.y)
                    
                    table?.position.x += offSetPosition.x
                    table?.position.y += offSetPosition.y
                    
                    posInitiale = location1
                    
                }*/
            
                let positionX: CGFloat? = t.location(in: self).x
                let positionY: CGFloat? = t.location(in: self).y
                let location1 = CGPoint(x: positionX!,y: positionY!)
                
                if ( atPoint(location1) == table || atPoint(location1).name == "background") {
                    //print("premier de dans")
                    for node in noeudSurTable {
                        
                        //for node in self.children {
                        
                        let noeud : SKSpriteNode! = node.noeud
                        
                        if noeud == node.noeud {
                        
                        //if let noeud = node as? SKSpriteNode {
                            //print("deuxieme ddedans")
                            let offSetPosition = CGPoint(x: location1.x - posInitiale!.x,y:location1.y - posInitiale!.y)
                            
                            noeud.position.x += offSetPosition.x
                            noeud.position.y += offSetPosition.y
                        }
                    }
                    let offSetPosition = CGPoint(x: location1.x - posInitiale!.x,y:location1.y - posInitiale!.y)
                    
                    table?.position.x += offSetPosition.x
                    table?.position.y += offSetPosition.y
                    
                    posInitiale = location1
                    
                }
            }
        }
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        //miseAJourSauvegarde()
        //print("nom de la carte: ", nomCarte)
        //print("path: ", pathFichier)
        for t in touches { self.touchUp(atPoint: t.location(in: self))}
       
        /*if(boolMur && effaceMur){
            print("hello")
            table!.children.last?.removeFromParent()
            effaceMur = false
        }*/
        for touch in touches{
            let location = touch.location(in: self)
            let touchedNode = atPoint(location)
            //print("position sur scene", location)
            //print(location)
            
            //print(touchedNode.name)
            //print(touchedNode)
            if let nom = touchedNode.name {
            //print(nom)
            switch nom {
                
            case "boutonAjoutPoteau" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                ajoutPoteau = true
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                ajoutDepart = false
                activeSelection = false
                deplacement = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplication = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonAjoutMur" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                ajoutMur = true
                ajoutPoteau = false
                ajoutLigne = false
                boolLigne = false
                ajoutDepart = false
                activeSelection = false
                deplacement = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplication = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonAjoutLigne" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                ajoutLigne = true
                ajoutMur = false
                boolMur = false
                ajoutPoteau = false
                ajoutDepart = false
                activeSelection = false
                deplacement = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplication = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonSelection" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                ajoutLigne = false
                ajoutMur = false
                boolMur = false
                ajoutPoteau = false
                ajoutDepart = false
                activeSelection = true
                deplacement = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplication = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonAjoutDepart" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                ajoutDepart = true
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                deplacement = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplication = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonDeplacement" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                deplacement = true
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplication = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonDuplication" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                //nbTap = 0
                duplication = true
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                scaleActive = false
                zoomActive = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonMiseAEchelle" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                //print("zoom")
                scaleActive = true
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonZoom" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                zoomActive = true
                scaleActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                activeDeplacementVue = false
                break
            case "boutonRotation" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                activeRotation = true
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeDeplacementVue = false
                break
            case "boutonSupprimer" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                activeDeplacementVue = false
                effacerNoeuds()
                break
            case "boutonDeplacementVue" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                activeDeplacementVue = true
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                break
            case "boutonEnregistrer" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                    indexLigne += 1
                    ajoutLigneTermine = false
                }*/
                activeDeplacementVue = false
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                
                // Enregistre la scene
                enregistrement()
                    
                    break
            case "boutonOuvrir" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                activeDeplacementVue = false
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                
                let alert: UIAlertController = UIAlertController(title: "Attention", message: "Toutes les modifications apportées seront effacées. Êtes-vous sûr de vouloir continuer?", preferredStyle: UIAlertControllerStyle.alert)
                
                
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action: UIAlertAction!) in
                    
                    // Retour au menu principal
                    var vueCourante: UIViewController = UIViewController()
                    vueCourante = self.view!.window!.rootViewController!
                    if(self.presentationListe){
                        self.viewController!.performSegue(withIdentifier: "ouvrir", sender: vueCourante)
                    } else {
                        self.viewController!.performSegue(withIdentifier: "ouvrirGrille", sender: vueCourante)
                    }
                }))
                alert.addAction(UIAlertAction(title: "Annuler", style: UIAlertActionStyle.cancel, handler: nil))
                
                self.viewController!.present(alert, animated: true, completion: nil)
                
                break
            case "boutonHome" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                    indexLigne += 1
                    ajoutLigneTermine = false
                }*/
                activeDeplacementVue = false
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                
                let alert: UIAlertController = UIAlertController(title: "Attention", message: "Toutes les modifications apportées seront effacées. Êtes-vous sûr de vouloir continuer?", preferredStyle: UIAlertControllerStyle.alert)
                
                
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action: UIAlertAction!) in
                    
                    // Retour au menu principal
                    var vueCourante: UIViewController = UIViewController()
                    vueCourante = self.view!.window!.rootViewController!
                    
                    self.viewController!.performSegue(withIdentifier: "home", sender: vueCourante)
                    
                }))
                alert.addAction(UIAlertAction(title: "Annuler", style: UIAlertActionStyle.cancel, handler: nil))
                
                self.viewController!.present(alert, animated: true, completion: nil)
                
                break
            case "boutonNouveau" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                activeDeplacementVue = false
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                
                let alert: UIAlertController = UIAlertController(title: "Attention", message: "Toutes les modifications apportées seront effacées. Êtes-vous sûr de vouloir continuer?", preferredStyle: UIAlertControllerStyle.alert)
    
                
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action: UIAlertAction!) in
                    
                self.toutSupprimer()
                self.counterDepart = 0
                self.ajoutDepart(CGPoint(x: -200,y: -150))
                    
                }))
                alert.addAction(UIAlertAction(title: "Annuler", style: UIAlertActionStyle.cancel, handler: nil))
                
                self.viewController!.present(alert, animated: true, completion: nil)
                break
            case "boutonTuto" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                activeDeplacementVue = false
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                
                let alert: UIAlertController = UIAlertController(title: "Attention", message: "Toutes les modifications apportées seront effacées. Êtes-vous sûr de vouloir continuer?", preferredStyle: UIAlertControllerStyle.alert)
                
                
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action: UIAlertAction!) in
                    
                    // Aller au tuto
                    var vueCourante: UIViewController = UIViewController()
                    vueCourante = self.view!.window!.rootViewController!
                    
                    self.viewController!.performSegue(withIdentifier: "tuto", sender: vueCourante)
                    
                }))
                alert.addAction(UIAlertAction(title: "Annuler", style: UIAlertActionStyle.cancel, handler: nil))
                
                self.viewController!.present(alert, animated: true, completion: nil)
                
                break
            case "boutonAnnuler" :
                // pour lier les lignes
                /*if(ajoutLigneTermine){
                 indexLigne += 1
                 ajoutLigneTermine = false
                 }*/
                activeDeplacementVue = false
                scaleActive = false
                zoomActive = false
                duplication = false
                deplacement = false
                ajoutDepart = false
                ajoutPoteau = false
                ajoutMur = false
                boolMur = false
                ajoutLigne = false
                boolLigne = false
                activeSelection = false
                continuerLigne = false
                deplacementEnCours = false
                creationMurF = false
                creationLigneF = false
                duplicationEnCours = false
                //ajoute = false
                //duplique = false
                activeRotation = false
                undo()
                //print("dedans")
                undoPossible = false
                
            default:
                break
                
            }
                //Selection touchEnded
                if (!nom.contains("bouton") && table!.contains(touch.location(in:self)))
                {
                    
                    if(activeSelection && nom != "table"){
                        objetSelectionne(touchedNode, location: location)
                    }
                }

            }
        }
        for tTable in touches { self.touchUp(atPoint: tTable.location(in: table!))
            let pos = tTable.location(in: table!)
            //print("position sur la table", pos)
        
            // if(!doubleTap){
            
            
                if(creationMurF){
                    xDernierClic = pos.x
                    yDernierClic = pos.y
                    let position = table!.childNode(withName: "murF")?.position
                    let longueur = table!.childNode(withName: "murF")?.xScale
                    let angle = table!.childNode(withName: "murF")?.zRotation
                    table!.childNode(withName: "murF")?.removeFromParent()
                
                    ajoutMurFinal(position!, longueur!, angle!)
                    boolMur = false
                    creationMurF = false
                
                }
                if(creationLigneF){
                    positionFinSegment = pos
                    xDernierClic = pos.x
                    yDernierClic = pos.y
                    let position = table!.childNode(withName: "segmentF")?.position
                    let longueur = table!.childNode(withName: "segmentF")?.xScale
                    let angle = table!.childNode(withName: "segmentF")?.zRotation
                    table!.childNode(withName: "segmentF")?.removeFromParent()
                
                    ajoutSegmentLigneFinale(position!, longueur!, angle!)
                    boolLigne = false
                    creationLigneF = false
                    continuerLigne = true
                    //print(indexLigne)
                
                    // Pour lier les lignes
                    //ensembleLignes[indexLigne].lignes.append((table?.children.last)!)
                    //ensembleLignes[indexLigne].nombreSegments += 1
                    //print(ensembleLignes[indexLigne].lignes)
                    //print("ensemble des lignes: ", ensembleLignes.count)
                    
                    ajoutLigneTermine = true
                
                }
                if(deplacementEnCours){
                    deplacementEnCours = false
                    annulerDeplacement = false
                    //deplace = true
                }
                if(duplicationEnCours){
                    duplicationEnCours = false
                    annulerDeplacementDuplication = false
                    //ancienneEtampe.append(contentsOf: etampe)
                    //print("ancienne up:" , ancienneEtampe.count)
                    ancienneEtampe.removeAll()
                    ancienneEtampe.append(contentsOf: etampe)
                    etampe.removeAll()
                }
            
            //} else {
            
            //    doubleTap = false
            
            //}
    }

        updateTextField()
        
        //mesObjetsSauvegardes.last?.afficherAttributs()
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        
        self.lastUpdateTime = currentTime
    }
    
    private func ajoutTable() {
        
        //table.physicsBody = SKPhysicsBody(texture: tableTexture, size: table.size)
        //table.position = CGPoint(x: size.width / 2, y: size.height / 2)
        table?.position = CGPoint(x: 0, y: 0)
        //table?.zPosition = -1
        //table.position = position

        insertChild(table!, at: 0)
    }
    
    private func ajoutPoteau(_ position : CGPoint) {
        let poteau = SKSpriteNode(texture: poteauTexture)
         poteau.name = "poteau"
        
        
        //table.physicsBody = SKPhysicsBody(texture: tableTexture, size: table.size)
        //table.position = CGPoint(x: size.width / 2, y: size.height / 2)
        //table.position = CGPoint(x: 0, y: 0)
        poteau.position = position
        poteau.zPosition = 1

        // if(poteau.intersects(table!)){
            if(surLaTable(poteau)){
             // if(surTable(location: poteau.position, node: poteau)) {
                table!.addChild(poteau)
                effetFumee(noeud: poteau)
                if(sonActif){
                    
                    AudioServicesPlaySystemSound(sonAjouter)
                }
                let objetSauvegarde = monObjetXML(noeud: poteau)
                mesObjetsSauvegardes.append(objetSauvegarde)
                //print(poteau.position)
               
            }
        // }
    
        /*table!.enumerateChildNodes(withName: "poteauJaune") {_,_ in
            self.counter += 1
        }
        print(table!.children)
        print(counter)*/
        
    }
    
    private func ajoutDepart(_ position : CGPoint) {
        if(counterDepart < 4){
        let depart = SKSpriteNode(texture: departTexture)
        depart.name = "fleche"

        depart.position = position
        depart.zPosition = 1
        
        if(depart.intersects(table!)){
            if(surLaTable(depart)){
            // if(surTable(location: depart.position, node: depart)){
                table!.addChild(depart)
                effetFumee(noeud: depart)
                if(sonActif){
                    
                    AudioServicesPlaySystemSound(sonAjouter)
                }
                let objetSauvegarde = monObjetXML(noeud: depart)
                mesObjetsSauvegardes.append(objetSauvegarde)
                counterDepart += 1
                //print("Dans ajout", counterDepart)
            }
        }
        }
    }
    
    private func ajoutMur(_ position : CGPoint) {
        let mur = SKSpriteNode(texture: murTexture)
        mur.name = "mur"
        
        
        //table.physicsBody = SKPhysicsBody(texture: tableTexture, size: table.size)
        //table.position = CGPoint(x: size.width / 2, y: size.height / 2)
        //table.position = CGPoint(x: 0, y: 0)
        mur.position = position
        mur.zPosition = 1
        
        if(mur.intersects(table!)){
            if(surLaTable(mur)){
            // if(surTable(location: mur.position, node: mur)){
            table!.addChild(mur)
            boolMur = true
            }
            
        }
        //print(boolMur)
    }
    
    private func ajoutMurFinal(_ position : CGPoint, _ longeur : CGFloat, _ angle : CGFloat) {
        let mur = SKSpriteNode(texture: murTexture)
        //print("scale mur ", murF.xScale)
        mur.name = "mur"

        mur.position = position
        mur.zPosition = 1
        //murF.setScale(longeur)
        if(longeur > mur.xScale){
            mur.xScale = longeur
        }
        mur.zRotation = angle
        
        if(mur.intersects(table!)){
            if(surLaTable(mur)){
            //if(surTable(location: mur.position, node: mur)){
                table!.addChild(mur)
                effetFumee(noeud: mur)
                if(sonActif){
                    
                    AudioServicesPlaySystemSound(sonAjouter)
                }
                let objetSauvegarde = monObjetXML(noeud: mur)
                
                /*objetSauvegarde.departX = xPremierClic
                objetSauvegarde.departY = yPremierClic
                objetSauvegarde.finX = xDernierClic
                objetSauvegarde.finY = yDernierClic*/
                
                mesObjetsSauvegardes.append(objetSauvegarde)
                /*print("attributs a l ajout")
                objetSauvegarde.afficherAttributs()
                print("fin des attributs a l ajout")*/
            }
        }
    }
    
    private func ajoutMurFantome(_ position : CGPoint, _ longeur : CGFloat, _ angle : CGFloat) {
        let murF = SKSpriteNode(texture: murTexture)
        //print("scale mur ", murF.xScale)
        murF.name = "murF"
        
        //table.physicsBody = SKPhysicsBody(texture: tableTexture, size: table.size)
        //table.position = CGPoint(x: size.width / 2, y: size.height / 2)
        //table.position = CGPoint(x: 0, y: 0)
        murF.position = position
        murF.zPosition = 1
        //murF.setScale(longeur)
        if(longeur > murF.xScale){
        murF.xScale = longeur
        }
        murF.zRotation = angle
        
        if(murF.intersects(table!)){
            //if(surLaTable(murF)){
            table!.addChild(murF)
        }
        creationMurF = true
    }
    
    private func ajoutSegmentLigneInit(_ position : CGPoint) {
        let segment = SKSpriteNode(texture: ligneTexture)
        segment.name = "segment"
        
        
        //table.physicsBody = SKPhysicsBody(texture: tableTexture, size: table.size)
        //table.position = CGPoint(x: size.width / 2, y: size.height / 2)
        //table.position = CGPoint(x: 0, y: 0)
        segment.position = position
        segment.zPosition = 1
        
        if(segment.intersects(table!)){
            if(surLaTable(segment)){
            // if(surTable(location: segment.position, node: segment)){
                table!.addChild(segment)
                boolLigne = true
            }
            
        }
        //print(boolMur)
    }
    
    private func ajoutSegmentLigneFantome(_ position : CGPoint, _ longeur : CGFloat, _ angle : CGFloat) {
        let segmentF = SKSpriteNode(texture: ligneTexture)
        //print("scale mur ", murF.xScale)
        segmentF.name = "segmentF"
        
        //table.physicsBody = SKPhysicsBody(texture: tableTexture, size: table.size)
        //table.position = CGPoint(x: size.width / 2, y: size.height / 2)
        //table.position = CGPoint(x: 0, y: 0)
        segmentF.position = position
        segmentF.zPosition = 1
        //murF.setScale(longeur)
        if(longeur > segmentF.xScale){
            segmentF.xScale = longeur
        }
        segmentF.zRotation = angle
        
        if(segmentF.intersects(table!)){
            //if(surLaTable(murF)){
            table!.addChild(segmentF)
        }
        creationLigneF = true
    }
    
    private func ajoutSegmentLigneFinale(_ position : CGPoint, _ longeur : CGFloat, _ angle : CGFloat) {
        let segment = SKSpriteNode(texture: ligneTexture)
        //print("scale mur ", murF.xScale)
        segment.name = "segment"
        
        segment.position = position
        segment.zPosition = 1
        //murF.setScale(longeur)
        if(longeur > segment.xScale){
            segment.xScale = longeur
        }
        segment.zRotation = angle
        
        if(segment.intersects(table!)){
            if(surLaTable(segment)){
            //if(surTable(location: segment.position, node: segment)){
                table!.addChild(segment)
                effetFumee(noeud: segment)
                if(sonActif){
                    
                    AudioServicesPlaySystemSound(sonAjouter)
                }
                let objetSauvegarde = monObjetXML(noeud: segment)
                /*objetSauvegarde.departX = xPremierClic
                objetSauvegarde.departY = yPremierClic
                objetSauvegarde.finX = xDernierClic
                objetSauvegarde.finY = yDernierClic*/
                mesObjetsSauvegardes.append(objetSauvegarde)
            } else {
                
                positionFinSegment = positionSegmentPrec
                
            }
        }
    }

    
    ///Fonction qui vérifie si le noeud est sur la table ou non
    /* func surTable(location: CGPoint, node: SKNode) -> Bool
    {
        if let noeud = node as? SKSpriteNode {
            //TODO: Changer l'accumulatedFrame par un test de collition physique...
            //On utilise l'accumulatedFrame pour prendre en compte la rotation et le scaling des objets
            let largeur = (noeud.calculateAccumulatedFrame().maxX - noeud.calculateAccumulatedFrame().minX)/2
            let hauteur = (noeud.calculateAccumulatedFrame().maxY - noeud.calculateAccumulatedFrame().minY)/2
            
            let gauche = CGPoint(x:location.x - largeur,y:location.y)
            let droite = CGPoint(x:location.x + largeur,y:location.y)
            let haut = CGPoint(x:location.x,y:location.y + hauteur)
            let bas = CGPoint(x:location.x,y:location.y - hauteur)
            if (table?.contains(gauche))! &&
                (table?.contains(droite))! &&
                (table?.contains(haut))! &&
                (table?.contains(bas))!
            {
                return true
            }
        }
        return false
    } */

    private func surLaTable(_ unNoeud : SKSpriteNode)-> Bool {
    
        //SKSpriteNode nouveauNoeud = unNoeud
        //self.addChild(unNoeud)
        let maxX = unNoeud.calculateAccumulatedFrame().maxX
        let maxY = unNoeud.calculateAccumulatedFrame().maxY
        let minX = unNoeud.calculateAccumulatedFrame().minX
        let minY = unNoeud.calculateAccumulatedFrame().minY
        
        /*let coinDroitMax = CGPoint(x: maxX, y: maxY)
        let coinDroitMin = CGPoint(x: maxX, y: minY)
        let coinGaucheMax = CGPoint(x: minX, y: maxY)
        let coinGaucheMin = CGPoint(x: minX, y: minY)*/
        
        let coinDroitMax = self.convert(CGPoint(x: maxX, y: maxY), from: table!)
        let coinDroitMin = self.convert(CGPoint(x: maxX, y: minY), from: table!)
        let coinGaucheMax = self.convert(CGPoint(x: minX, y: maxY), from: table!)
        let coinGaucheMin = self.convert(CGPoint(x: minX, y: minY), from: table!)
        //print("frame : ", table?.frame)
        //print(coinDroitMax)
        
        if(table!.frame.contains(coinDroitMax) && table!.frame.contains(coinDroitMin) && table!.frame.contains(coinGaucheMax) && table!.frame.contains(coinGaucheMin)) {
            estSurLaTable = true
        } else {
            estSurLaTable = false
        }
        
        return estSurLaTable
        //unNoeud.
    }
    
    public func longPressed() {
        if(boolLigne){
        table!.children.last?.removeFromParent()
        boolLigne = false
        indexLigne += 1
        }
        creationLigneF = false
        continuerLigne = false
        
    }
    
    public func doubleTapped() {
        //print("Hello")
        
        //if(!doubleTap){
          /*  if(ajoute){
                /*if(table!.children.last?.name ==  "fleche"){
                    counterDepart -= 2
                    //print("doubleTap ", counterDepart)
                }*/
                
                
                var deux = 0
                for objet in mesObjetsSauvegardes {
                    if(deux < 2 && objet.noeud == table!.children.last){
                    
                        let indiceObjet = mesObjetsSauvegardes.index(where: {$0 === objet})
                        mesObjetsSauvegardes.remove(at: indiceObjet!)
                        table!.children.last?.removeFromParent()
                        deux += 1
                    
                    }
                }
                
                
                let tabDepart = table!.children.filter{ ($0.name == "fleche")}
                counterDepart = tabDepart.count
                print(counterDepart)
            }
            if(duplique){
                for noeud in ancienneEtampe {
                    noeud.removeFromParent()
                    for objet in mesObjetsSauvegardes {
                        if(objet.noeud == noeud){
                            let indiceObjet = mesObjetsSauvegardes.index(where: {$0 === objet})
                            mesObjetsSauvegardes.remove(at: indiceObjet!)
                        }
                    }
                }
                
                print("ancienne :" , ancienneEtampe.count)
                ancienneEtampe.removeAll()
                
            
            }
            
            doubleTap = true
        //}
        if(ajoute){
            if(table!.children.last?.name ==  "fleche"){
                counterDepart -= 2
                //print("doubleTap ", counterDepart)
            }
            table!.children.last?.removeFromParent()
            table!.children.last?.removeFromParent()
            
        }
    
        if(duplique){
            if(nbTap>1){
                nbTap -= nbNoeudsDupliques/2
            while(nbNoeudsDupliques>0){
                if(table!.children.last?.name == "fleche"){
                    counterDepart -= 1
                }
                table!.children.last?.removeFromParent()
                nbNoeudsDupliques -= 1
                
                
            }
                
            } else {
                nbNoeudsDupliques /= 2
                while(nbNoeudsDupliques>0){
                    if(table!.children.last?.name == "fleche"){
                        counterDepart -= 1
                    }
                    table!.children.last?.removeFromParent()
                    nbNoeudsDupliques -= 1
                    
                }
                nbTap = 0
            }
        //sceneNode?.children.first?.children.last?.removeFromParent()
    }*/
    }
    
    //Selection des objets
    func objetSelectionne(_ touchedNode: SKNode, location: CGPoint){
        
        let objetSelectionne = touchedNode as? SKSpriteNode
        
        // Pour lier les lignes
        
        /*if noeudSelectionne.contains(objetSelectionne!)
        {
            if(objetSelectionne?.name == "segment"){
                for ligne in ensembleLignes{
                    for segment in ligne.lignes {
                        if(objetSelectionne == segment){
                            for segment in ligne.lignes{
                                deselectionnerObjet(segment as? SKSpriteNode)
                            }
                        }
                    }
                }
            } else {
            deselectionnerObjet(objetSelectionne)
            }
        }else
        {
            if(objetSelectionne?.name == "segment"){
                for ligne in ensembleLignes{
                    for segment in ligne.lignes {
                        if(objetSelectionne == segment){
                            for segment in ligne.lignes{
                                selectionnerObjet(segment as? SKSpriteNode)
                            }
                        }
                    }
                }
            } else {
            selectionnerObjet(objetSelectionne)
            }
            
        }*/
        
        if noeudSelectionne.contains(objetSelectionne!)
        {
            deselectionnerObjet(objetSelectionne)
        }else
        {
            selectionnerObjet(objetSelectionne)
        }
        
    }
    
    func selectionnerObjet(_ objetSelectionne: SKSpriteNode?) {
        
        objetSelectionne!.color = UIColor.blue
        objetSelectionne!.alpha = 0.9
        objetSelectionne!.colorBlendFactor = 1
        noeudSelectionne.append(objetSelectionne!)
        if(sonActif){
            
            AudioServicesPlaySystemSound(sonSelectionner)
        }
        activerOuDesactiverBoutonSupprimer()
        
    }
    
    ///Fonction qui désélectionne un objet
    func deselectionnerObjet(_ objetSelectionne: SKSpriteNode?) {
        
        
        
        noeudSelectionne = noeudSelectionne.filter {$0 !==
            objetSelectionne!}
        objetSelectionne!.color = UIColor.white
        objetSelectionne!.alpha = 1
        objetSelectionne!.colorBlendFactor = 1
        
        if( noeudSelectionne.isEmpty){
            activerOuDesactiverBoutonSupprimer()
        }
        
    }
    
    
    func deplacerObjet(locationInit: CGPoint, locationFinal: CGPoint){
    
        if(!noeudSelectionne.isEmpty){
        let differenceX = locationFinal.x - locationInit.x
        let differenceY = locationFinal.y - locationInit.y
        noeudPosition.removeAll()
        
        for i in 0...(noeudSelectionne.count - 1){
        
        let anciennePos = CGPoint(x: noeudSelectionne[i].position.x, y: noeudSelectionne[i].position.y)
        noeudPosition.append(anciennePos)
        // noeudPositionsAnciennes.append(anciennePos)
        
            noeudSelectionne[i].position.x += differenceX
            noeudSelectionne[i].position.y += differenceY
            if(!surLaTable(noeudSelectionne[i])){
            // if(!surTable(location: noeudSelectionne[i].position, node: noeudSelectionne[i])){
                annulerDeplacement = true
                
            }
        }
        
        //x1 + (x2 - x1)
        }
    }
    
    func verifierDeplacement() {
    
        if(annulerDeplacement){
            for i in 0...(noeudSelectionne.count - 1){
                /*for objet in mesObjetsSauvegardes {
                    if(objet.noeud == noeudSelectionne[i]){
                        print("allo")
                        objet.departX = objet.ancienDepart.x
                        objet.departY = objet.ancienDepart.y
                        objet.finX = objet.ancienFin.x
                        objet.finX = objet.ancienFin.y
                        objet.posX = noeudPosition[i].x
                        objet.posY = noeudPosition[i].y
                    }
                }*/
                    noeudSelectionne[i].position = noeudPosition[i]
                
            }
        
        } else {
            miseAJourSauvegarde()
        }
        
    }
    
    func dupliquer() {
        if(!noeudSelectionne.isEmpty){
        nbNoeudsDupliques = 0
        for i in 0...(noeudSelectionne.count - 1){
            if(noeudSelectionne[i].name == "fleche")
            {
                if(counterDepart<4){
                    let node = SKSpriteNode(texture: noeudSelectionne[i].texture)
                    node.name = noeudSelectionne[i].name
                    node.position = noeudSelectionne[i].position
                    node.zPosition = 1
                    node.zRotation = noeudSelectionne[i].zRotation
                    node.xScale = noeudSelectionne[i].xScale
                    node.yScale = noeudSelectionne[i].yScale
                    let objetSauvegarde = monObjetXML(noeud: node)
                    mesObjetsSauvegardes.append(objetSauvegarde)
                    table!.addChild(node)
                    etampe.append(node)
                    nbNoeudsDupliques += 2
                    counterDepart += 1
                }
            } else {
                    let node = SKSpriteNode(texture: noeudSelectionne[i].texture)
                    node.name = noeudSelectionne[i].name
                    node.position = noeudSelectionne[i].position
                    node.zPosition = 1
                    node.zRotation = noeudSelectionne[i].zRotation
                    node.xScale = noeudSelectionne[i].xScale
                    node.yScale = noeudSelectionne[i].yScale
                    let objetSauvegarde = monObjetXML(noeud: node)
                    mesObjetsSauvegardes.append(objetSauvegarde)
                    table!.addChild(node)
                    etampe.append(node)
                    nbNoeudsDupliques += 2
                }
            //print("Nombre de noeuds ", nbNoeudsDupliques)
        }
            //ancienneEtampe.append(contentsOf: etampe)
        }
    }
    
    func deplacerEtampe(locationInit: CGPoint, locationFinal: CGPoint){
        let differenceX = locationFinal.x - locationInit.x
        let differenceY = locationFinal.y - locationInit.y
        noeudPosition.removeAll()
        
        if(etampe.count>0){
        for i in 0...(etampe.count - 1){
            
            let anciennePos = CGPoint(x: etampe[i].position.x, y: etampe[i].position.y)
            noeudPosition.append(anciennePos)
            
            
            etampe[i].position.x += differenceX
            etampe[i].position.y += differenceY
            
            //print(surLaTable(etampe[i]))
            if(!surLaTable(etampe[i])){
            // if(surTable(location: etampe[i].position, node: etampe[i])){
                annulerDeplacementDuplication = true
                
            }
        }
        }
    }
    
    func verifierDuplication() {
        
        if(annulerDeplacementDuplication){
            for i in 0...(etampe.count - 1){
                etampe[i].position = noeudPosition[i]
                
            }
            
        } else {
            miseAJourSauvegardeDuplication()
        }
        
    }
    
    // Fonction calculant le centre
    
    func calculerCentre() -> CGPoint{
        var xMax = noeudSelectionne[0].position.x
        var minX = noeudSelectionne[0].position.x
        var yMax = noeudSelectionne[0].position.y
        var minY = noeudSelectionne[0].position.y
        
        for node in noeudSelectionne
        {
            if node.position.x > xMax
            {
                xMax = node.position.x
            }
            if node.position.x < minX
            {
                minX = node.position.x
            }
            if node.position.y > yMax
            {
                yMax = node.position.y
            }
            if node.position.y < minY{
                minY = node.position.y
            }
        }
        return CGPoint(x: (((xMax-minX)/2)+minX), y: (((yMax-minY)/2)+minY))
    }
    
    //Fonction de rotation
    
    
    func rotation(_ sender: UIRotationGestureRecognizer){
        if (activeRotation == true)
        {
            if sender.state == .changed
            {
                if noeudSelectionne.count == 1
                {
                    let pos = noeudSelectionne.first!.zRotation
                    noeudSelectionne.first!.zRotation -= sender.rotation
                    //degreeRotation += sender.rotation
                    //tableauRotation.append(ObjetRotation(noeud: noeudSelectionne.first!, angle: degreeRotation))
                    if(!surLaTable(noeudSelectionne.first!)){
                        noeudSelectionne.first!.zRotation = pos
                    }
                    
                    sender.rotation = 0
                }else if noeudSelectionne.count > 1
                {
                    for dot in noeudSelectionne
                    {
                        
                        //degreeRotation += sender.rotation
                        let dx = dot.position.x - pointCentral.x
                        let dy = dot.position.y - pointCentral.y
                        
                        let angleCourant = atan(dy / dx)
                        let prochainAngle = angleCourant - sender.rotation
                        let rotationRadius = dot.position.distance(pointCentral)
                        
                        
                        let nouveau_x = dx >= 0 ? pointCentral.x + rotationRadius * cos(prochainAngle) : pointCentral.x - rotationRadius * cos(prochainAngle)
                        let nouveau_y = dx >= 0 ? pointCentral.y + rotationRadius * sin(prochainAngle) : pointCentral.y - rotationRadius * sin(prochainAngle)
                        let nouveau_point = CGPoint(x: nouveau_x, y: nouveau_y)
                        
                        let pos = dot.position
                        let rot = dot.zRotation
                        dot.position = nouveau_point
                        //dot.position = self.convert(nouveau_point, from: table!)
                        dot.zRotation = dot.zRotation - sender.rotation
                        
                        if (!surLaTable(dot))
                        {
                        // if(surTable(location: dot.position, node: dot)){
                            dot.position = pos
                            dot.zRotation = rot
                        }
                        
                        //tableauRotation.append(ObjetRotation(noeud: dot, angle: degreeRotation))
                    }
                    
                    sender.rotation = 0
                }
            }
            if (sender.state == .began)
            {
                if noeudSelectionne.count > 1
                {
                    pointCentral = calculerCentre()
                    //centreRotation = pointCentral
                } /*else {
                    centreRotation = noeudSelectionne[0].position
                }*/
            }
            if sender.state == .ended
            {
                //print("fin de la rotation")
                miseAJourSauvegarde()
                //degreeRotation = 0
            }
            
        }
    }
    
    // Fonction pour effacer les noeuds
    
    func effacerNoeuds(){
        //print("nombre objets avant: ", mesObjetsSauvegardes.count)
        /*if(!noeudSelectionne.isEmpty){
        efface = true
        mesObjetsAnnules.removeAll()
        for noeud in noeudSelectionne{
            mesObjetsAnnules.append(ObjetAnnuler(noeud: noeud))
        }
        
        }*/
        
        if noeudSelectionne.count == 1
        {
            /*(noeudSelectionne.first?.name == "fleche"){
                counterDepart -= 1
            }*/
            noeudSelectionne.first?.removeFromParent()
            effetExplosion(noeud: noeudSelectionne[0])
            
            if(sonActif){
                
                AudioServicesPlaySystemSound(sonSupprimer)
            }
            
            for objet in mesObjetsSauvegardes {
                
                if(objet.noeud == noeudSelectionne[0]){
                    /*if let i = mesObjetsSauvegardes.index(where:  { _ in (objet.noeud == noeudSelectionne[0])}) {
                        print("i: ", i)
                    }*/
                    
                    let indiceObjet = mesObjetsSauvegardes.index(where: {$0 === objet})
                    mesObjetsSauvegardes.remove(at: indiceObjet!)
                    
                    //indiceDuNoeud -= 1
                }
                
                //indiceDuNoeud += 1
            }
            
            let tabDepart = table!.children.filter{ ($0.name == "fleche")}
            counterDepart = tabDepart.count
        }
        else if noeudSelectionne.count > 1
        {
            for dot in noeudSelectionne
            {
                /*if(dot.name == "fleche"){
                    counterDepart -= 1
                }*/
                for objet in mesObjetsSauvegardes {
                    
                    if(objet.noeud == dot){
                        
                        /*print("indice efface: ", indiceDuNoeud)
                        mesObjetsSauvegardes.remove(at: indiceDuNoeud)
                        print("nombre objets dedans: ", mesObjetsSauvegardes.count)
                        indiceDuNoeud -= 1
                    } else if (indiceDuNoeud<mesObjetsSauvegardes.count-1){
                        print("indice non dedans: ", indiceDuNoeud)
                        indiceDuNoeud += 1*/
                        
                        let indiceObjet = mesObjetsSauvegardes.index(where: {$0 === objet})
                        mesObjetsSauvegardes.remove(at: indiceObjet!)
                    }
                }
                deselectionnerObjet(dot)
                dot.removeFromParent()
                effetExplosion(noeud: dot)
                //AudioServicesPlaySystemSound(sonSupprimer)
            }
            
            if(sonActif){
                
                AudioServicesPlaySystemSound(sonSupprimer)
            }
            let tabDepart = table!.children.filter{ ($0.name == "fleche")}
            counterDepart = tabDepart.count
        }
        
        activerOuDesactiverBoutonSupprimer()
        noeudSelectionne.removeAll()
        //print("nombre objets après: ", mesObjetsSauvegardes.count)
    }
    
    func initialiserTextField(){
        
        // Propriétés: position X
        positionXProp = UITextField(frame: CGRect(x: 147 , y: 152, width: 60, height: 20))
        //positionXProp?.isHidden = false
        
        positionXProp?.addTarget(self, action: #selector(textFieldPositionDidChange(_:)), for: .editingChanged)
        positionXProp?.borderStyle = UITextBorderStyle.roundedRect
        positionXProp?.textColor = SKColor.black
        positionXProp?.backgroundColor = UIColor.clear
        positionXProp?.placeholder = ""
        positionXProp?.isEnabled = false
        positionXProp?.isHidden = false

        
        view?.addSubview(positionXProp!)
        
        // Propriétés: position Y
        positionYProp = UITextField(frame: CGRect(x: 347 , y: 152, width: 60, height: 20))
        //positionXProp?.isHidden = false
        
         positionYProp?.addTarget(self, action: #selector(textFieldPositionDidChange(_:)), for: .editingChanged)
        positionYProp?.borderStyle = UITextBorderStyle.roundedRect
        positionYProp?.textColor = SKColor.black
        positionYProp?.backgroundColor = UIColor.clear
        positionYProp?.placeholder = ""
        positionYProp?.isEnabled = false
        positionYProp?.isHidden = false
        
        view?.addSubview(positionYProp!)
        
        // Propriétés: Rotation
        rotationProp = UITextField(frame: CGRect(x: 530, y: 152, width: 60, height: 20))
        //positionXProp?.isHidden = false
        
        rotationProp?.addTarget(self, action: #selector(textFieldRotationDidChange(_:)), for: .editingChanged)
        rotationProp?.borderStyle = UITextBorderStyle.roundedRect
        rotationProp?.textColor = SKColor.black
        rotationProp?.backgroundColor = UIColor.clear
        rotationProp?.placeholder = ""
        rotationProp?.isEnabled = false
        rotationProp?.isHidden = false
        
        view?.addSubview(rotationProp!)
        
        // Propriétés: Mise à l'échelle
        echelleProp = UITextField(frame: CGRect(x: 697, y: 152, width: 60, height: 20))
        //positionXProp?.isHidden = false
        
        echelleProp?.addTarget(self, action: #selector(textFieldEchelleDidChange(_:)), for: .editingChanged)
        echelleProp?.borderStyle = UITextBorderStyle.roundedRect
        echelleProp?.textColor = SKColor.black
        echelleProp?.backgroundColor = UIColor.clear
        echelleProp?.placeholder = ""
        echelleProp?.isEnabled = false
        echelleProp?.isHidden = false
        
        view?.addSubview(echelleProp!)
    }
    
    func updateTextField(){
        
        //barreDeProprietesActive(true)
        if (noeudSelectionne.count == 1){
            positionXProp!.text = NSString(format: "%.0f", noeudSelectionne[0].position.x) as String
            positionYProp!.text = NSString(format: "%.0f", noeudSelectionne[0].position.y) as String
            rotationProp!.text = NSString(format: "%.01f", noeudSelectionne[0].zRotation) as String
            echelleProp!.text = NSString(format: "%.01f", noeudSelectionne[0].xScale) as String
            
            /*positionXProp?.isHidden = false
            positionYProp?.isHidden = false
            rotationProp?.isHidden = false
            echelleProp?.isHidden = false*/
            
            positionXProp?.isEnabled = true
            positionXProp?.backgroundColor = UIColor.white
            
            positionYProp?.isEnabled = true
            positionYProp?.backgroundColor = UIColor.white
            
            rotationProp?.isEnabled = true
            rotationProp?.backgroundColor = UIColor.white
            
            echelleProp?.isEnabled = true
            echelleProp?.backgroundColor = UIColor.white
            
        } else {
            
            //barreDeProprietesActive(false)
            
            positionXProp!.text = ""
            positionYProp!.text = ""
            rotationProp!.text = ""
            echelleProp!.text = ""
    
            /*positionXProp?.isHidden = true
            positionYProp?.isHidden = true
            rotationProp?.isHidden = true
            echelleProp?.isHidden = true*/
            
            positionXProp?.isEnabled = false
            positionXProp?.backgroundColor = UIColor.clear
            
            positionYProp?.isEnabled = false
            positionYProp?.backgroundColor = UIColor.clear
            
            rotationProp?.isEnabled = false
            rotationProp?.backgroundColor = UIColor.clear
            
            echelleProp?.isEnabled = false
            echelleProp?.backgroundColor = UIColor.clear
        }
    }
    
    // Fonction qui permettent la modification des textField (Propriétés)
    
    func textFieldPositionDidChange(_ textField: UITextField) {
        
        if(noeudSelectionne.count == 1){
            
            let anciennePos = CGPoint(x: noeudSelectionne[0].position.x, y: noeudSelectionne[0].position.y)
            
            let convertir = NumberFormatter()
            convertir.decimalSeparator = "."
        
            if(positionXProp?.text != "" && positionYProp?.text != ""){
                if let newX = convertir.number(from: (positionXProp?.text!)!){
                    if let newY = convertir.number(from: (positionYProp?.text!)!){
                        let x = CGFloat(newX)
                        let y = CGFloat(newY)
                        let nouvellePos = CGPoint(x: x, y: y)
                        noeudSelectionne[0].position = nouvellePos
                        if(!surLaTable(noeudSelectionne[0])){
                        // if(surTable(location: noeudSelectionne[0].position, node: noeudSelectionne[0])){
                            noeudSelectionne[0].position = anciennePos
                            positionXProp!.text! = noeudSelectionne[0].position.x.description
                            positionYProp!.text! = noeudSelectionne[0].position.y.description
                        }
                    } else {
                        updateTextField()
                    }
                } else {
                    updateTextField()
                }
                
                miseAJourSauvegarde()
            }
        }
    }
    
    
    func textFieldRotationDidChange(_ textField: UITextField) {
        if(noeudSelectionne.count == 1){
            
            let ancienneRot = CGFloat(noeudSelectionne[0].zRotation)
            
            let convertir = NumberFormatter()
            convertir.decimalSeparator = "."
            
            if(rotationProp!.text != ""){
                if let newZ = convertir.number(from: (rotationProp!.text!)){
                    let z = CGFloat(newZ)
                    noeudSelectionne[0].zRotation = z * CGFloat(M_PI) / 180
                    if(!surLaTable(noeudSelectionne[0])){
                    //if(surTable(location: noeudSelectionne[0].position, node: noeudSelectionne[0])){
                        noeudSelectionne[0].zRotation = ancienneRot
                        rotationProp!.text! = noeudSelectionne[0].zRotation.description
                    }
                } else {
                    updateTextField()
                }
                
                miseAJourSauvegarde()
            }
        }
        
    }
    
    // à modifier (pour le y surtout) -> vérifier avec Samia
    func textFieldEchelleDidChange(_ textField: UITextField) {
        if(noeudSelectionne.count == 1){
            
            let ancienneScaX = CGFloat(noeudSelectionne[0].xScale)
            let ancienneScaY = CGFloat(noeudSelectionne[0].yScale)
            
            let convertir = NumberFormatter()
            convertir.decimalSeparator = "."
            
            if(echelleProp!.text != ""){
                if let newScale = convertir.number(from: (echelleProp!.text!)){
                    let scale = CGFloat(newScale)
                    
                    if scale >= 1.0 {
                        if(noeudSelectionne[0].name == "poteau"){
                        noeudSelectionne[0].xScale = scale
                        noeudSelectionne[0].yScale = scale
                        
                        } else if (noeudSelectionne[0].name == "mur") {
                            
                            noeudSelectionne[0].xScale = scale
                            
                        }
                        
                        if(!surLaTable(noeudSelectionne[0])){
                        //if(surTable(location: noeudSelectionne[0].position, node: noeudSelectionne[0])){
                            noeudSelectionne[0].xScale = ancienneScaX
                            noeudSelectionne[0].yScale = ancienneScaY
                            echelleProp!.text! = noeudSelectionne[0].xScale.description
                        }
                    }
                } else {
                    updateTextField()
                }
                
                miseAJourSauvegarde()
            }
        }
    }
    
    func barreDeProprietesActive(_ unBool: Bool){
        if(unBool){
            self.childNode(withName: "barProp")?.isHidden = false
        } else {
            self.childNode(withName: "barProp")?.isHidden = true
            
        }
        
    }
    
    // Implémentation du zoom et de la mise à l'échelle
    
    func zoomer(sender: UIPinchGestureRecognizer){
        
        if (sender.state == .began){
            //print(sender.scale)
            // le pincement débute
            /* mesObjetsAnnules.removeAll()
            for noeud in noeudSelectionne{
                mesObjetsAnnules.append(ObjetAnnuler(noeud: noeud))
            }*/
        }
        if sender.state == .changed {
            //au  cours  du pincement
            if (scaleActive == true) {
                
                if (noeudSelectionne.count > 0 ){
                    for objet in noeudSelectionne {
                        
                        let largeurInitiale = objet.xScale
                        let hauteurInitiale = objet.yScale
                        //noeudScaleAncien.append(CGPoint(x: largeurInitiale, y: hauteurInitiale))
                        //mesObjetsAnnules.append(ObjetAnnuler(noeud: objet))
                        if objet.name=="poteau" {
                            
                            objet.xScale *= sender.scale
                            objet.yScale *= sender.scale
                            if (surLaTable(objet) == false) {
                            //if(!surTable(location: objet.position, node: objet)){
                                objet.xScale = largeurInitiale
                                objet.yScale = hauteurInitiale
                            }else{
                                objet.xScale *= sender.scale
                                objet.yScale *= sender.scale
                            }
                        }
                        else if objet.name=="mur" {
                            objet.xScale *= sender.scale
                            
                            if (surLaTable(objet) == false) {
                            // if(!surTable(location: objet.position, node: objet)){
                                objet.xScale = largeurInitiale
                                objet.yScale = hauteurInitiale
                            }else{
                                objet.xScale *= sender.scale
                                
                            }
                            
                            
                        }
                    }
                    
                }
                
                sender.scale = 1 //On reset le scale du sender pour pas faire exponentiel
                miseAJourSauvegarde()
            }
            
            
        else{
            
            //maintenant on zoom la vue au complet
            
            if (zoomActive == true){
                //print(sender.scale)
                //print(table!.frame)
                let nouveauScale = initialscaleTable * sender.scale
                if nouveauScale >= 0.5 && nouveauScale <= 1.48 {
                    
                    
                    for objet in noeudSurTable {
                        objet.posAvantScale = (table?.convert(objet.noeud.position, from: self))!
                    }
                    
                    
                    table?.xScale *= sender.scale
                    table?.yScale *= sender.scale
                    initialscaleTable = nouveauScale
                    
                    //print("position objet: ", table?.childNode(withName: "poteau")?.position)
                    
                    for objet in noeudSurTable {
                        objet.noeud.xScale *= sender.scale
                        objet.noeud.yScale *= sender.scale
                        objet.noeud.position = self.convert(objet.posAvantScale, from: table!)
                        //print("position objet: ",objet.noeud.position)
                    }
                }
                // print("Apres zoom table!.frame")
                //print(table!.frame)
                sender.scale = 1 //On reset le scale du sender
            }
        }
        }
    }
    
    // Fonction permettant d'activer ou de desactiver le bouton supprimer
    
    func activerOuDesactiverBoutonSupprimer(){
        if(noeudSelectionne.count >= 1){
            barOutil.childNode(withName: "boutonSupprimer")?.alpha = 1
            barOutil.childNode(withName: "boutonSupprimer")?.isUserInteractionEnabled = false
            //print("boutonSupprimer activé")
        }
        else
        {
            barOutil.childNode(withName: "boutonSupprimer")?.alpha = 0
            barOutil.childNode(withName: "boutonSupprimer")?.isUserInteractionEnabled = true
            
            //print("boutonSupprimer Désactivé")
        }
        
    }
    func toutSupprimer(){
        table!.removeAllChildren()
        mesObjetsSauvegardes.removeAll()
        noeudSelectionne.removeAll()
        noeudSurTable.removeAll()
        //mesObjetsAnnules.removeAll()
        
    }
    
    func cartePossedeDepart() -> Bool{
        var possedeDepart = false
        for objet in mesObjetsSauvegardes {
            if(objet.type == "fleche"){
                possedeDepart = true
            }
        }
        return possedeDepart
    }
    
    func enregistrerVignette (image: UIImage, path: String ){
        
        let pngVignette: NSData!
        pngVignette = UIImagePNGRepresentation(image) as NSData!
        pngVignette.write(toFile: path, atomically: true)
    }
    
    func enregistrerXML (path: String){
        let sauvegarde = AEXMLDocument()
        let configuration = sauvegarde.addChild(name: "configuration")
        let attributCScene = ["CALCULS_PAR_IMAGE" : "50"]
        let CScene = configuration.addChild(name: "CScene", attributes: attributCScene)
        for objet in mesObjetsSauvegardes{
            
            let attributs = ["ID" : "\(objet.id)", "Type" : "\(objet.type)", "Affiche" : "\(objet.affiche)", "Enregistrable" : "\(objet.enregistrable)", "Selectionnable" : "\(objet.selectionnable)", "Angle" : "\(objet.angle)", "x" : "\(objet.x)", "y" : "\(objet.y)", "z" : "\(objet.z)", "Pos_x" : "\(objet.posX)", "Pos_y": "\(objet.posY)", "Pos_z": "\(objet.posZ)", "Redim_x" : "\(objet.redimX)", "Redim_y" : "\(objet.redimY)", "Redim_z" : "\(objet.redimZ)"]
                
                /*, "Depart_x" : "\(objet.departX)" , "Depart_y" : "\(objet.departY)", "Depart_z" : "\(objet.departZ)", "Fin_x" : "\(objet.finX)" , "Fin_y" : "\(objet.finY)", "Fin_z" : "\(objet.finZ)"]*/
            
            switch (objet.type){
            case "fleche" :
                CScene.addChild(name: "fleche", attributes: attributs)
                break
            case "poteau" :
                CScene.addChild(name: "poteau", attributes: attributs)
                break
            case "mur" :
                CScene.addChild(name: "mur", attributes: attributs)
                break
            case "segment" :
                let attributsLigne = ["ID" : "\(NSUUID().uuidString)", "Type" : "ligne", "Affiche" : "1", "Enregistrable" : "1", "Selectionnable" : "1", "Angle" : "0", "x" : "0", "y" : "0", "z" : "0", "Pos_x" : "0", "Pos_y": "0", "Pos_z": "0", "Redim_x" : "1", "Redim_y" : "1", "Redim_z" : "1"]
                let ligne = CScene.addChild(name: "ligne", attributes: attributsLigne)
                ligne.addChild(name: "segment", attributes: attributs)
                break
            default:
                break
            }
        }
        
        let xmlString = sauvegarde.xml
        do {
            
            _ = try xmlString.write(toFile: path, atomically: true, encoding: String.Encoding.utf8)
            
        }
        catch {
            print("\(error)")
        }
    }
    
    func enregistrement(){
        
        // Vérification du point de départ
        
        if(self.cartePossedeDepart()){
        /*var tableauSelection = noeudSelectionne
            for noeud in noeudSelectionne{
                deselectionnerObjet(noeud)
            }*/

        let screenShot = self.view?.screenShot()
        
        let fileManager = FileManager.default
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        //print(documentDirectory)
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Cartes")
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
            
        // Création de l'alerte pour l'enregistrement (diaog box)
        let alert: UIAlertController = UIAlertController(title: "Enregistrement",
        message: "Voulez-vous enregistrer cette carte?", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addTextField { (unTextField) in
            
            unTextField.placeholder = "Veuillez entrer le nom de la carte"
            //unTextField.placeholder = pathCourant as! String
        }
        
        alert.addAction(UIAlertAction(title: "Enregistrer", style: UIAlertActionStyle.default, handler: { (action: UIAlertAction!) in
            var texte: String
            texte = (alert.textFields?.first?.text)!
            
            //print(texte)
            
            let carteNomXml = "/" + texte + ".xml"
            let carteNomImage = "/" + texte + ".png"
            
            self.imagePath = pathFileName + carteNomImage
            self.xmlPath = pathFileName + carteNomXml
            
            if fileManager.fileExists(atPath: self.imagePath) {
                
                let existe: UIAlertController = UIAlertController(title: "Attention",
                                                                 message: "Une carte portant le même nom a déjà été enregistrée. Souhaitez-vous la remplacer?", preferredStyle: UIAlertControllerStyle.alert)
                
                existe.addAction(UIAlertAction(title: "Enregistrer", style: UIAlertActionStyle.default, handler: { (action: UIAlertAction!) in
                    self.enregistrerVignette(image: screenShot!, path: self.imagePath)
                    self.enregistrerXML(path: self.xmlPath)
                    //print(self.xmlPath)
                    
                    self.updateTextField()
                    let succes = UIAlertController(title: "Félicitation", message: "Votre carte a bien été enregistrée", preferredStyle: UIAlertControllerStyle.alert)
                    succes.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.viewController!.present(succes, animated: true, completion: nil)

                }))
                existe.addAction(UIAlertAction(title: "Annuler", style: UIAlertActionStyle.cancel,
                                              handler: nil))
                self.viewController!.present(existe, animated: true, completion: nil)
            } else {
            
                
                self.enregistrerVignette(image: screenShot!, path: self.imagePath)
                self.enregistrerXML(path: self.xmlPath)
                //print(self.xmlPath)
            //let s = SauvegardeXML()
            
            
            
                self.updateTextField()
           
            
            let succes = UIAlertController(title: "Félicitation", message: "Votre carte a bien été enregistrée", preferredStyle: UIAlertControllerStyle.alert)
            succes.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.viewController!.present(succes, animated: true, completion: nil)
            //}
            }
        
        }))
        alert.addAction(UIAlertAction(title: "Annuler", style: UIAlertActionStyle.cancel,
                                      handler: nil))
        
        //var vueCourant: UIViewController = UIViewController()
        
        
        self.viewController!.present(alert, animated: true, completion: nil)
        
        } else {
            let depart = UIAlertController(title: "Enregistrement impossible", message: "Votre carte doit contenir au moins un point de départ", preferredStyle: UIAlertControllerStyle.alert)
            depart.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.viewController!.present(depart, animated: true, completion: nil)
        }
    }
    
    
    func chargement(){
        toutSupprimer()
        counterDepart = 0
        let parseur = ParseurXml()
        parseur.chargerXML(nomFichier: nomCarte, path: pathFichier)
        for objet in parseur.mesObjetsCharges{
            if(objet.type == "fleche"){
                let node = SKSpriteNode(texture: departTexture)
                node.name = objet.type
                node.position = CGPoint(x: objet.posX, y: objet.posY)
                node.zPosition = objet.posZ
                node.zRotation = objet.angle
                node.xScale = objet.redimX
                node.yScale = objet.redimY
                table!.addChild(node)
                mesObjetsSauvegardes.append(monObjetXML(noeud: node))
                counterDepart += 1
                
            }
            else if(objet.type == "poteau"){
                let node = SKSpriteNode(texture: poteauTexture)
                node.name = objet.type
                node.position = CGPoint(x: objet.posX, y: objet.posY)
                node.zPosition = objet.posZ
                node.zRotation = objet.angle
                node.xScale = objet.redimX
                node.yScale = objet.redimY
                table!.addChild(node)
                mesObjetsSauvegardes.append(monObjetXML(noeud: node))
                
            }
            else if(objet.type == "mur"){
                let node = SKSpriteNode(texture: murTexture)
                node.name = objet.type
                node.position = CGPoint(x: objet.posX, y: objet.posY)
                node.zPosition = objet.posZ
                node.zRotation = objet.angle
                node.xScale = objet.redimX
                node.yScale = objet.redimY
                table!.addChild(node)
                mesObjetsSauvegardes.append(monObjetXML(noeud: node))
                
            }
            else if(objet.type == "segment"){
                let node = SKSpriteNode(texture: ligneTexture)
                node.name = objet.type
                node.position = CGPoint(x: objet.posX, y: objet.posY)
                node.zPosition = objet.posZ
                node.zRotation = objet.angle
                node.xScale = objet.redimX
                node.yScale = objet.redimY
                table!.addChild(node)
                mesObjetsSauvegardes.append(monObjetXML(noeud: node))
                
            }
        }
        
    }
    
    func miseAJourSauvegarde(){
        
        if(!noeudSelectionne.isEmpty){
            //indexDegreeObjet = 0
            for noeud in noeudSelectionne {
                for objet in mesObjetsSauvegardes {
                    if(objet.noeud == noeud){
                        
                        /*if(deplacement && (!(objet.posX == noeud.position.x) || !(objet.posY == noeud.position.y))){
                            if(noeud.name != "poteau"){
                                let differenceX = noeud.position.x - objet.posX
                                let  differenceY = noeud.position.y - objet.posY
                                objet.departX += differenceX
                                objet.departY += differenceY
                                objet.finX += differenceX
                                objet.finY += differenceY
                            }
                        
                        }
                    
                        if(activeRotation && !(objet.angle == noeud.zRotation)){
                            if(noeud.name != "poteau"){
                                for rotateObj in tableauRotation {
                                    if(objet.noeud == rotateObj.noeud){
                                        let targetDepart = CGPoint(x: objet.departX, y: objet.departY)
                                        let targetFin = CGPoint(x: objet.finX, y: objet.finY)
                                        //let nouveauPtDepart = rotatePoint(target: targetDepart, aroundOrigin: centreRotation, byDegrees: tableauDegree[indexDegreeObjet])
                                        //let nouveauPtFin = rotatePoint(target: targetFin, aroundOrigin: centreRotation, byDegrees: tableauDegree[indexDegreeObjet])
                                        let nouveauPtDepart = rotatePoint(target: targetDepart, aroundOrigin: centreRotation, byDegrees: degreeRotation)
                                        let nouveauPtFin = rotatePoint(target: targetFin, aroundOrigin: centreRotation, byDegrees: degreeRotation)
                                        objet.departX = nouveauPtDepart.x
                                        objet.departY = nouveauPtDepart.y
                                        objet.finX = nouveauPtFin.x
                                        objet.finY = nouveauPtFin.y
                                        
                                    }
                                
                                }
                                
                            }
                        }*/
                        
                        objet.posX = noeud.position.x
                        objet.posY = noeud.position.y
                        objet.angle = noeud.zRotation
                        objet.redimX = noeud.xScale
                        objet.redimY = noeud.yScale
                    
                        /*objet.afficherAttributs()
                        print("nom noeud", noeud.name)
                        print("noeud position", noeud.position)
                        print("rotation noeud", noeud.zRotation)
                        print("noeud xScale", noeud.xScale)*/
                        
                    }
                }
                
                //indexDegreeObjet += 1
            }
            
            //tableauRotation.removeAll()
        }
        
    }
    
    func miseAJourSauvegardeDuplication() {
    
        if(!etampe.isEmpty){
            //indexDegreeObjet = 0
            for noeud in etampe {
                for objet in mesObjetsSauvegardes {
                    if(objet.noeud == noeud){
    
                        objet.posX = noeud.position.x
                        objet.posY = noeud.position.y
                        objet.angle = noeud.zRotation
                        objet.redimX = noeud.xScale
                        objet.redimY = noeud.yScale
    
   
    
                    }
                }
    
 
            }
    
    
        }
    
    }
    
    /*func rotatePoint(target: CGPoint, aroundOrigin origin: CGPoint, byDegrees: CGFloat) -> CGPoint {
     
        /*
     
        // Référence : http://stackoverflow.com/questions/35683376/rotating-a-cgpoint-around-another-cgpoint
        rotatePoint(target: CGPoint, aroundOrigin origin: CGPoint, byDegrees: CGFloat) -> CGPoint
        let dx = target.x - origin.x
        let dy = target.y - origin.y
        let radius = sqrt(dx * dx + dy * dy)
        //let azimuth = atan2(dy, dx) // in radians
        let azimuth = atan(dy / dx)
        //let newAzimuth = azimuth + byDegrees * CGFloat(M_PI / 180.0) // convert it to radians
        let newAzimuth = azimuth + byDegrees
        let x = origin.x + radius * cos(newAzimuth)
        let y = origin.y + radius * sin(newAzimuth)
        return CGPoint(x: x, y: y)*/
     
        let dx = target.x - origin.x
        let dy = target.y - origin.y
     
        let angleCourant = atan(dy / dx)
        let prochainAngle = angleCourant - byDegrees
        let rotationRadius = target.distance(origin)
     
     
        let nouveau_x = dx >= 0 ? origin.x + rotationRadius * cos(prochainAngle) : origin.x - rotationRadius * cos(prochainAngle)
        let nouveau_y = dx >= 0 ? origin.y + rotationRadius * sin(prochainAngle) : origin.y - rotationRadius * sin(prochainAngle)
        return CGPoint(x: nouveau_x, y: nouveau_y)
      
    }*/
    
    func effetExplosion (noeud :SKSpriteNode)
    {
        let path = Bundle.main.path(forResource: "explosion",ofType: "sks")
        let explosion = NSKeyedUnarchiver.unarchiveObject(withFile: path!) as! SKEmitterNode
        addChild(explosion)
        explosion.numParticlesToEmit = 200
        //explosion.position = noeud.position
        explosion.position = self.convert(noeud.position, from: table!)
    }
    
    func effetFumee (noeud :SKSpriteNode)
    {
        let path = Bundle.main.path(forResource: "smoke",ofType: "sks")
        let fumee = NSKeyedUnarchiver.unarchiveObject(withFile: path!) as! SKEmitterNode
        addChild(fumee)
        fumee.numParticlesToEmit = 1
        fumee.position = self.convert(noeud.position, from: table!)
    }
    
    func undo (){
        
        if(undoPossible){
            //print("undo")
        if(duplique){
            for noeud in ancienneEtampe {
                noeud.removeFromParent()
                for objet in mesObjetsSauvegardes {
                    if(objet.noeud == noeud){
                        let indiceObjet = mesObjetsSauvegardes.index(where: {$0 === objet})
                        mesObjetsSauvegardes.remove(at: indiceObjet!)
                    }
                }
            }
            
            //print("ancienne :" , ancienneEtampe.count)
            ancienneEtampe.removeAll()
        }
        if(ajoute){
           //print("ajoute")
            for objet in mesObjetsSauvegardes {
                //print("dedans")
                if(objet.noeud == table!.children.last){
                    //print("dedans dedans")
                    let indiceObjet = mesObjetsSauvegardes.index(where: {$0 === objet})
                    mesObjetsSauvegardes.remove(at: indiceObjet!)
                    
 
                }
            }
            
            table!.children.last?.removeFromParent()
            let tabDepart = table!.children.filter{ ($0.name == "fleche")}
            counterDepart = tabDepart.count
        }
        /*if(efface){
                for node in mesObjetsAnnules{
                    table!.addChild(node.noeud)
                    mesObjetsSauvegardes.append(monObjetXML(noeud: node.noeud))
                }
            }
        
            for noeud in mesObjetsAnnules{
                for nodes in noeudSelectionne{
                    if(noeud.noeud == nodes){
                        nodes.xScale = noeud.scale.x
                        nodes.yScale = noeud.scale.y
                        nodes.position = noeud.position
                        nodes.zRotation = noeud.angleRotation
                    }
                }
            }
            print("objet sauv count: ", mesObjetsSauvegardes.count)
            print("objet sur table: ", table!.children.count)
            miseAJourSauvegarde()
            mesObjetsAnnules.removeAll()*/
        }
        //print("objet sauv count: ", mesObjetsSauvegardes.count)
        //print("objet sur table: ", table!.children.count)
    }
}
