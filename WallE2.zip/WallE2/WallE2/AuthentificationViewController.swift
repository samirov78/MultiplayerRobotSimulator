//
//  AuthentificationViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-07.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit

class AuthentificationViewController: UIViewController {
    
    @IBOutlet weak var retourMenu: UIButton!
    @IBOutlet weak var disconectBnt: UIButton!
    @IBOutlet weak var connectBnt: UIButton!
    /*@IBOutlet weak var GrilleEdition: UIButton!
    @IBOutlet weak var ButtonReglage: UIButton!
    @IBOutlet weak var ButtonCreerProfil: UIButton!
    @IBOutlet var ButtonEditionLigne: UIView!
    @IBOutlet weak var ButtonEdition: UIButton!
    @IBOutlet weak var ButtonStatistiques: UIButton!*/
    var parseurReglage = ParseurXmlReglages()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        parseurReglage.chargerXML()
        mettreAJourReglages()
        connectBnt.layer.cornerRadius = 10
        disconectBnt.layer.cornerRadius = 10
        retourMenu.layer.cornerRadius = 10
        // préparer quelle vue de présentation va être visible
        /*GrilleEdition.isHidden = true
        GrilleEdition.isEnabled = false
        ButtonEdition.isHidden = true
        ButtonEdition.isEnabled = false
        
        GrilleEdition.layer.cornerRadius = 10
        ButtonEdition.layer.cornerRadius = 10
        ButtonStatistiques.layer.cornerRadius = 10
        ButtonEditionLigne.layer.cornerRadius = 10
        ButtonCreerProfil.layer.cornerRadius = 10
        ButtonReglage.layer.cornerRadius = 10
        
        if(parseurReglage.mesReglages.presentation == "liste"){
            GrilleEdition.isHidden = true
            GrilleEdition.isEnabled = false
            ButtonEdition.isHidden = false
            ButtonEdition.isEnabled = true
        }
        if(parseurReglage.mesReglages.presentation == "grille"){
            ButtonEdition.isHidden = true
            ButtonEdition.isEnabled = false
            GrilleEdition.isHidden = false
            GrilleEdition.isEnabled = true
        }*/
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.view.isHidden = true
    }
}
