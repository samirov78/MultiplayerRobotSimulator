//
//  CreationProfilViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-07.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit
import SwiftSocket

class CreationProfilViewController: UIViewController {
    
    @IBOutlet weak var retourMenu: UIButton!
    @IBOutlet weak var ButtonInscrire: UIButton!
    @IBOutlet weak var nom: UITextField!
    @IBOutlet weak var prenom: UITextField!
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var motPasse: UITextField!
    @IBOutlet weak var confirmMotPasse: UITextField!
    @IBOutlet weak var courriel: UITextField!
    
    @IBOutlet weak var prop: UIButton!
    @IBOutlet weak var port: UITextField!
    @IBOutlet weak var serveur: UITextField!
    private var estConnecte = false
    private var success = false
    private var touchID = TouchID(interface: "creation")
    /*@IBOutlet weak var GrilleEdition: UIButton!
    @IBOutlet weak var ButtonReglage: UIButton!
    @IBOutlet weak var ButtonCreerProfil: UIButton!
    @IBOutlet var ButtonEditionLigne: UIView!
    @IBOutlet weak var ButtonEdition: UIButton!
    @IBOutlet weak var ButtonStatistiques: UIButton!*/
    var parseurReglage = ParseurXmlReglages()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        parseurReglage.chargerXML()
        mettreAJourReglages()
        prop.layer.cornerRadius = 10
        ButtonInscrire.layer.cornerRadius = 10
        retourMenu.layer.cornerRadius = 10
        // préparer quelle vue de présentation va être visible
        /*GrilleEdition.isHidden = true
        GrilleEdition.isEnabled = false
        ButtonEdition.isHidden = true
        ButtonEdition.isEnabled = false
        
        GrilleEdition.layer.cornerRadius = 10
        ButtonEdition.layer.cornerRadius = 10
        ButtonStatistiques.layer.cornerRadius = 10
        ButtonEditionLigne.layer.cornerRadius = 10
        ButtonCreerProfil.layer.cornerRadius = 10
        ButtonReglage.layer.cornerRadius = 10
        
        if(parseurReglage.mesReglages.presentation == "liste"){
            GrilleEdition.isHidden = true
            GrilleEdition.isEnabled = false
            ButtonEdition.isHidden = false
            ButtonEdition.isEnabled = true
        }
        if(parseurReglage.mesReglages.presentation == "grille"){
            ButtonEdition.isHidden = true
            ButtonEdition.isEnabled = false
            GrilleEdition.isHidden = false
            GrilleEdition.isEnabled = true
        }*/
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    @IBAction func creationDuProfil(_ sender: Any) {
        
        let user : String? = self.user.text
        let nom : String? = self.nom.text
        let prenom : String? = self.prenom.text
        let motPasse : String? = self.motPasse.text
        let confirmMotPasse : String? = self.confirmMotPasse.text
        let courriel : String? = self.courriel.text
        let serveur : String? = self.serveur.text
        let port : String? = self.port.text
        
        if(!(motPasse?.isEmpty)! && !(confirmMotPasse?.isEmpty)! && !(courriel?.isEmpty)! && !(user?.isEmpty)! && !(serveur?.isEmpty)! && !(port?.isEmpty)! && !(nom?.isEmpty)! && !(prenom?.isEmpty)!){
        if(motPasse != confirmMotPasse){
            
            
            
            let alert: UIAlertController = UIAlertController(title: "Attention",
                                                             message: "Le mot de passe de confirmation ne correspond pas au mot de passe initial",preferredStyle: UIAlertControllerStyle.alert)
            let submitAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
            alert.addAction(submitAction)
            present(alert, animated : true , completion : nil)
        }
        else
        {
            
            
            let client = TCPClient(address: serveur!, port: Int32(port!)!)
            switch client.connect(timeout: 10) {
            case .success:
                print("Connected to host \(client.address)")
                self.estConnecte = true
                let  message  = "1;"+"0;"+user!+";"+prenom!+";"+nom!+";"+Encode(data1: motPasse!)+";"+courriel!+";"+"0;"
                
                let bytes2 = [UInt8](message.utf8)
                print(bytes2)
                
                let t  = UInt32((message.lengthOfBytes(using: String.Encoding.utf8)))
                print(t)
                let bytes = toByteArray(t)
                
                let  toSend = bytes + bytes2
                print(toSend)
                client.send(data : toSend)
            //may be add control here later
            case .failure(let error):
                self.estConnecte = false
                print(error)
                
            }
            
            
            while(estConnecte)
            {
                //  print ("renter ds while")
                guard let data = client.read(1024*10) else { return }
                if let response = String(bytes: data, encoding: .utf8)
                {
                    let index = response.index(response.startIndex,offsetBy:4)
                    let newResponse=response.substring(from: index)
                    
                    print (newResponse)
                    
                    let commaSeparatedArray = response.components(separatedBy: ";")
                    //let firstIndice : String = commaSeparatedArray[0]
                    let code : String = commaSeparatedArray[1]
                    
                    if (code == "2")
                    {
                        
                        //print("profil crée, vous pouvez vous connecter")
                        //print("Profil crée")
                        let alert1: UIAlertController = UIAlertController(title: "Félicitation", message: "Votre profil vient d'être créé, vous avez reçu un mail de confirmation ",           preferredStyle: UIAlertControllerStyle.alert)
                        let submitAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
                        alert1.addAction(submitAction)
                        present(alert1, animated : true , completion : nil)
                        estConnecte = false
                        success = true
                    }
                    else if (code == "1")
                    {
                        
                        //print("login ou user  déja utilisé,veuillez rentrer un autre login")
                        let alert2: UIAlertController = UIAlertController(title: "Login déja utilisé", message: "Veuillez entrer un autre nom d'utilisateur ", preferredStyle: UIAlertControllerStyle.alert)
                        //let submitAction =
                        alert2.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        present(alert2, animated : true , completion : nil)
                        estConnecte = false
                    }
                    
                    // }
                }
            }
        }
        } else {
            let echec = UIAlertController(title: "Attention", message: "Vous n'avez pas rempli tous les champs", preferredStyle: UIAlertControllerStyle.alert)
            echec.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            present(echec, animated: true, completion: nil)
        }
    }
    
    ////////////////////////////////////////////////////////////
    func toByteArray<T>(_ value: T) -> [UInt8]{
        var value = value
        return withUnsafePointer(to: &value) {
            $0.withMemoryRebound(to: UInt8.self, capacity: MemoryLayout<T>.size) {
                Array(UnsafeBufferPointer(start: $0, count: MemoryLayout<T>.size))
            }
        }
    }
    
    func Encode(data1: String) -> String {
        
        data1.replacingOccurrences(of: "%s", with: "%%s")
        
        return data1.replacingOccurrences(of: ";", with: "%s")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.view.isHidden = true
    }
    
    @IBAction func touchIDDown(_ sender: Any) {
        if(success){
            touchID.recupererValeur(login: user.text!, mdp: motPasse.text!)
            touchID.TouchID()
        }
    }
    
}
