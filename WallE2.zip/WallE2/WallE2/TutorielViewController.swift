//
//  TutorielViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-10.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit
import AEXML

class TutorielViewController: UIViewController, UIViewControllerTransitioningDelegate {
    
    @IBOutlet weak var retourEdition: UIButton!
    @IBOutlet weak var text: UITextView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var leftBtn: UIButton!
    @IBOutlet weak var rightBtn: UIButton!
    var visionne = false
    var nomImageCourante = "Tuto1"
    var tutoXmlPath = ""
    var parseurReglage = ParseurXmlReglages()
    
    // Effet de transition
    let animationController = AnimationController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        parseurReglage.chargerXML()
        mettreAJourReglages()
        leftBtn.layer.cornerRadius = 10
        rightBtn.layer.cornerRadius = 10
        retourEdition.layer.cornerRadius = 10
        visionne = true
    }
    @IBAction func goRight(_ sender: Any) {
        switch(nomImageCourante){
            case "Tuto1":
                nomImageCourante = "Tuto2"
                image.image = #imageLiteral(resourceName: "Tuto2")
                text.text = "Vous pouvez choisir des objets dans le menu en bas à gauche de l'écran (encadré en rouge) et les ajouter sur la table au centre de l'écran. Les objets disponibles sont: des poteaux, des points de départ, des murs et des lignes. Les objets ne peuvent pas être ajoutés hors de la table."
                text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto2":
            nomImageCourante = "Tuto3"
            image.image = #imageLiteral(resourceName: "Tuto3")
            text.text = "Pour ajouter un poteau ou un point de départ, il vous suffit de toucher l'écran à l'endroit où vous souhaitez ajouter l'objet en question."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto3":
            nomImageCourante = "Tuto4"
            image.image = #imageLiteral(resourceName: "Tuto4")
            text.text = "L'ajout du mur s'effectue en trois étapes. La première est de toucher l'endroit où vous souhaitez commencer le mur. La seconde est de déplacer votre doigt dans la direction voulue afin de définir son angle et sa taille. La troisième est de relever votre doigt à l'endroit où vous souhaitez terminer le mur."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto4":
            nomImageCourante = "Tuto5"
            image.image = #imageLiteral(resourceName: "Tuto5")
            text.text = "Une ligne est composée de un ou plusieurs segments. L'ajout d'un segment de ligne s'effectue de la même façon que l'ajout du mur. Les segments vont automatiquement s'ajouter les uns après les autres. Pour arrêter d'ajouter des segments à une même ligne il suffit de presser longtemps l'écran (long press gesture)."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto5":
            nomImageCourante = "Tuto6"
            image.image = #imageLiteral(resourceName: "Tuto6")
            text.text = "Vous pouvez choisir des outils dans le menu en bas à droite de l'écran (encadré en rouge). Les outils disponibles de gauche à droite sur la première ligne sont: la sélection, la rotation, la mise à l'échelle et le déplacement de la vue. Les outils disponibles de gauche à droite sur la seconde ligne sont: le déplacement des objets, la duplication, la supression et le zoom de la table."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto6":
            nomImageCourante = "Tuto7"
            image.image = #imageLiteral(resourceName: "Tuto7")
            text.text = "La sélection et la déselection sont actives uniquement si l'outil sélection (encadré en rouge) a été touché au préalable. Pour sélectionner un ou plusieurs objets il suffit de toucher le ou les objets. Pour déselectionner un objet il suffit de le toucher à nouveau. Les interactions sur les objets sont possibles uniquement si ces derniers sont sélectionnés."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto7":
            nomImageCourante = "Tuto8"
            image.image = #imageLiteral(resourceName: "Tuto8")
            text.text = "La rotation est active uniquement si l'outil rotation (encadré en rouge) a été touché au préalable. Pour effectuer la rotation d'un ou de plusieurs objets il suffit de déposer deux doits sur l'écran et d'effectuer une rotation de ces deux doigts dans le sens désiré (rotation gesture)."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto8":
            nomImageCourante = "Tuto9"
            image.image = #imageLiteral(resourceName: "Tuto9")
            text.text = "La mise à l'échelle est active uniquement si l'outil mise à l'échelle (encadré en rouge) a été touché au préalable. Pour effectuer la mise à l'échelle d'un ou de plusieurs objets il suffit de déposer deux doigts sur l'écran et de les rapprocher ou de les éloigner en fonction de la taille désirée (pinch gesture). Seuls les murs et les poteaux peuvent être mis à l'échelle."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto9":
            nomImageCourante = "Tuto10"
            image.image = #imageLiteral(resourceName: "Tuto10")
            text.text = "Le déplacement de la vue est actif uniquement si l'outil déplacement de la vue (encadré en rouge) a été touché au préalable. Pour effectuer un déplacement de la vue il suffit de toucher l'écran et de déplacer le doigt dans le sens désiré."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto10":
            nomImageCourante = "Tuto11"
            image.image = #imageLiteral(resourceName: "Tuto11")
            text.text = "Le déplacement d'un objet est actif uniquement si l'outil déplacement d'un objet (encadré en rouge) a été touché au préalable. Pour effectuer le déplacement d'un ou de plusieurs objets il suffit de toucher l'écran et de déplacement son doigt en direction de position souhaitée."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto11":
            nomImageCourante = "Tuto12"
            image.image = #imageLiteral(resourceName: "Tuto12")
            text.text = "La duplication est active uniquement si l'outil duplication (encadré en rouge) a été touché au préalable. Pour effectuer une duplication d'un ou de plusieurs objets il suffit de toucher l'écran pour dupliquer le ou les objets sélectionnés et de déplacer son doigt pour les placer à la position désirée."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto12":
            nomImageCourante = "Tuto13"
            image.image = #imageLiteral(resourceName: "Tuto13")
            text.text = "La supression est active uniquement si au moins un objet est sélectionné. Pour supprimer un ou plusieurs objets il suffit de toucher l'outil supression (encadré en rouge). Seuls les objets sélectionnés sont effacés."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto13":
            nomImageCourante = "Tuto14"
            image.image = #imageLiteral(resourceName: "Tuto14")
            text.text = "Le zoom est actif uniquement si l'outil zoom (encadré en rouge) a été touché au préalable. Pour s'éloigner de la table il suffit de poser deux doigts sur l'écran et de les rapprocher. Pour se rapprocher de la table il suffit de poser deux doigts sur l'écran et de les éloigner."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto14":
            nomImageCourante = "Tuto15"
            image.image = #imageLiteral(resourceName: "Tuto15")
            text.text = "Lorsqu'un objet est sélectionné, vous avez la possibilité de changer sa position en x et en y, son angle de rotation et sa taille grâce à la barre de propriétés (encadrée en rouge). Les champs éditables sont visibles uniquement quand un seul objet est sélectionné. Pour modifier leur valeur il suffit simplement de les toucher et d'entrer les nouvelles valeurs grâce au clavier intégré."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto15":
            nomImageCourante = "Tuto16"
            image.image = #imageLiteral(resourceName: "Tuto16")
            text.text = "Tout en haut de l'éditeur, dans la barre de menu (encadrée en rouge), vous avez la possibilité de choisir l'une des fonctionnalités suivante (de gauche à droite): retourner au menu principal, ouvrir une nouvelle carte vierge, ouvrir une carte existante, enregistrer la carte courante, ouvrir le tutoriel et annuler un ajout."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto16":
            nomImageCourante = "Tuto17"
            image.image = #imageLiteral(resourceName: "Tuto17")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: retourner au menu principal, votre carte actuelle est supprimée et vous êtes redirigés vers le menu d'accueil. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto17":
            nomImageCourante = "Tuto18"
            image.image = #imageLiteral(resourceName: "Tuto18")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: ouvrir une nouvelle carte vierge, votre carte actuelle est supprimée et une nouvelle carte vierge apparaît. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto18":
            nomImageCourante = "Tuto19"
            image.image = #imageLiteral(resourceName: "Tuto19")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: ouvrir une carte existante, votre carte actuelle est supprimée et vous êtes redirigés vers l'interface de choix des cartes. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto19":
            nomImageCourante = "Tuto20"
            image.image = #imageLiteral(resourceName: "Tuto20")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: enregistrer la carte courante, un message d'alerte s'affiche pour vous permettre de nommer votre carte et de l'enregistrer. Si une carte du même nom existe déjà et que vous confirmez l'enregistrement, elle est écrasée. Si votre carte ne possède pas de point de départ, l'enregistrement de cette dernière est impossible."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto20":
            nomImageCourante = "Tuto21"
            image.image = #imageLiteral(resourceName: "Tuto21")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: ouvrir le tutoriel, votre carte actuelle est supprimée et vous êtes redirigés vers l'interface du tutoriel. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto21":
            nomImageCourante = "Tuto22"
            image.image = #imageLiteral(resourceName: "Tuto22")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: annuler un ajout, vous avez deux possibilités: soit le dernier objet ajouté est supprimé (si vous venez de faire un ajout), soit la dernière duplication est supprimée (si vous venez de dupliquer des objets). Cette fonctionnalité est utilisée uniquement dans le cas d'un ajout ou d'une duplication."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto22":
            nomImageCourante = "Tuto23"
            image.image = #imageLiteral(resourceName: "Tuto23")
            text.text = "Merci d'avoir regardé ce tutoriel! Vous pouvez maintenant retourner à l'interface d'édition et commencez à éditer vos cartes."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto23":
            nomImageCourante = "Tuto1"
            image.image = #imageLiteral(resourceName: "Tuto1")
            text.text = "Bienvenue dans le tutoriel de WallE2. Vous allez maintenant apprendre à utiliser les différents outils et fonctionnalités de l'édition."
            text.adjustsFontForContentSizeCategory = true
            break
        default:
            break
        }
    }
    
    @IBAction func left(_ sender: Any) {
        switch(nomImageCourante){
        case "Tuto3":
            nomImageCourante = "Tuto2"
            image.image = #imageLiteral(resourceName: "Tuto2")
            text.text = "Vous pouvez choisir des objets dans le menu en bas à gauche de l'écran (encadré en rouge) et les ajouter sur la table au centre de l'écran. Les objets disponibles sont: des poteaux, des points de départ, des murs et des lignes. Les objets ne peuvent pas être ajoutés hors de la table."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto4":
            nomImageCourante = "Tuto3"
            image.image = #imageLiteral(resourceName: "Tuto3")
            text.text = "Pour ajouter un poteau ou un point de départ, il vous suffit de toucher l'écran à l'endroit où vous souhaitez ajouter l'objet en question."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto5":
            nomImageCourante = "Tuto4"
            image.image = #imageLiteral(resourceName: "Tuto4")
            text.text = "L'ajout du mur s'effectue en trois étapes. La première est de toucher l'endroit où vous souhaitez commencer le mur. La seconde est de déplacer votre doigt dans la direction voulue afin de définir son angle et sa taille. La troisième est de relever votre doigt à l'endroit où vous souhaitez terminer le mur."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto6":
            nomImageCourante = "Tuto5"
            image.image = #imageLiteral(resourceName: "Tuto5")
            text.text = "Une ligne est composée de un ou plusieurs segments. L'ajout d'un segment de ligne s'effectue de la même façon que l'ajout du mur. Les segments vont automatiquement s'ajouter les uns après les autres. Pour arrêter d'ajouter des segments à une même ligne il suffit de presser longtemps l'écran (long press gesture)."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto7":
            nomImageCourante = "Tuto6"
            image.image = #imageLiteral(resourceName: "Tuto6")
            text.text = "Vous pouvez choisir des outils dans le menu en bas à droite de l'écran (encadré en rouge). Les outils disponibles de gauche à droite sur la première ligne sont: la sélection, la rotation, la mise à l'échelle et le déplacement de la vue. Les outils disponibles de gauche à droite sur la seconde ligne sont: le déplacement des objets, la duplication, la supression et le zoom de la table."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto8":
            nomImageCourante = "Tuto7"
            image.image = #imageLiteral(resourceName: "Tuto7")
            text.text = "La sélection et la déselection sont actives uniquement si l'outil sélection (encadré en rouge) a été touché au préalable. Pour sélectionner un ou plusieurs objets il suffit de toucher le ou les objets. Pour déselectionner un objet il suffit de le toucher à nouveau. Les interactions sur les objets sont possibles uniquement si ces derniers sont sélectionnés."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto9":
            nomImageCourante = "Tuto8"
            image.image = #imageLiteral(resourceName: "Tuto8")
            text.text = "La rotation est active uniquement si l'outil rotation (encadré en rouge) a été touché au préalable. Pour effectuer la rotation d'un ou de plusieurs objets il suffit de déposer deux doits sur l'écran et d'effectuer une rotation de ces deux doigts dans le sens désiré (rotation gesture)."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto10":
            nomImageCourante = "Tuto9"
            image.image = #imageLiteral(resourceName: "Tuto9")
            text.text = "La mise à l'échelle est active uniquement si l'outil mise à l'échelle (encadré en rouge) a été touché au préalable. Pour effectuer la mise à l'échelle d'un ou de plusieurs objets il suffit de déposer deux doigts sur l'écran et de les rapprocher ou de les éloigner en fonction de la taille désirée (pinch gesture). Seuls les murs et les poteaux peuvent être mis à l'échelle."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto11":
            nomImageCourante = "Tuto10"
            image.image = #imageLiteral(resourceName: "Tuto10")
            text.text = "Le déplacement de la vue est actif uniquement si l'outil déplacement de la vue (encadré en rouge) a été touché au préalable. Pour effectuer un déplacement de la vue il suffit de toucher l'écran et de déplacer le doigt dans le sens désiré."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto12":
            nomImageCourante = "Tuto11"
            image.image = #imageLiteral(resourceName: "Tuto11")
            text.text = "Le déplacement d'un objet est actif uniquement si l'outil déplacement d'un objet (encadré en rouge) a été touché au préalable. Pour effectuer le déplacement d'un ou de plusieurs objets il suffit de toucher l'écran et de déplacement son doigt en direction de position souhaitée."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto13":
            nomImageCourante = "Tuto12"
            image.image = #imageLiteral(resourceName: "Tuto12")
            text.text = "La duplication est active uniquement si l'outil duplication (encadré en rouge) a été touché au préalable. Pour effectuer une duplication d'un ou de plusieurs objets il suffit de toucher l'écran pour dupliquer le ou les objets sélectionnés et de déplacer son doigt pour les placer à la position désirée."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto14":
            nomImageCourante = "Tuto13"
            image.image = #imageLiteral(resourceName: "Tuto13")
            text.text = "La supression est active uniquement si au moins un objet est sélectionné. Pour supprimer un ou plusieurs objets il suffit de toucher l'outil supression (encadré en rouge). Seuls les objets sélectionnés sont effacés."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto15":
            nomImageCourante = "Tuto14"
            image.image = #imageLiteral(resourceName: "Tuto14")
            text.text = "Le zoom est actif uniquement si l'outil zoom (encadré en rouge) a été touché au préalable. Pour s'éloigner de la table il suffit de poser deux doigts sur l'écran et de les rapprocher. Pour se rapprocher de la table il suffit de poser deux doigts sur l'écran et de les éloigner."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto16":
            nomImageCourante = "Tuto15"
            image.image = #imageLiteral(resourceName: "Tuto15")
            text.text = "Lorsqu'un objet est sélectionné, vous avez la possibilité de changer sa position en x et en y, son angle de rotation et sa taille grâce à la barre de propriétés (encadrée en rouge). Les champs éditables sont visibles uniquement quand un seul objet est sélectionné. Pour modifier leur valeur il suffit simplement de les toucher et d'entrer les nouvelles valeurs grâce au clavier intégré."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto17":
            nomImageCourante = "Tuto16"
            image.image = #imageLiteral(resourceName: "Tuto16")
            text.text = "Tout en haut de l'éditeur, dans la barre de menu (encadrée en rouge), vous avez la possibilité de choisir l'une des fonctionnalités suivante (de gauche à droite): retourner au menu principal, ouvrir une nouvelle carte vierge, ouvrir une carte existante, enregistrer la carte courante, ouvrir le tutoriel et annuler un ajout."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto18":
            nomImageCourante = "Tuto17"
            image.image = #imageLiteral(resourceName: "Tuto17")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: retourner au menu principal, votre carte actuelle est supprimée et vous êtes redirigés vers le menu d'accueil. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto19":
            nomImageCourante = "Tuto18"
            image.image = #imageLiteral(resourceName: "Tuto18")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: ouvrir une nouvelle carte vierge, votre carte actuelle est supprimée et une nouvelle carte vierge apparaît. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto20":
            nomImageCourante = "Tuto19"
            image.image = #imageLiteral(resourceName: "Tuto19")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: ouvrir une carte existante, votre carte actuelle est supprimée et vous êtes redirigés vers l'interface de choix des cartes. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto21":
            nomImageCourante = "Tuto20"
            image.image = #imageLiteral(resourceName: "Tuto20")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: enregistrer la carte courante, un message d'alerte s'affiche pour vous permettre de nommer votre carte et de l'enregistrer. Si une carte du même nom existe déjà et que vous confirmez l'enregistrement, elle est écrasée. Si votre carte ne possède pas de point de départ, l'enregistrement de cette dernière est impossible."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto22":
            nomImageCourante = "Tuto21"
            image.image = #imageLiteral(resourceName: "Tuto21")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: ouvrir le tutoriel, votre carte actuelle est supprimée et vous êtes redirigés vers l'interface du tutoriel. Un message d'alerte s'affiche pour prévenir que cette action entraîne la perte vos modifications sur la carte actuelle. Vous pouvez continuer ou annuler."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto23":
            nomImageCourante = "Tuto22"
            image.image = #imageLiteral(resourceName: "Tuto22")
            text.text = "Si vous touchez l'image (encadrée en rouge) associée à la fonctionnalité: annuler un ajout, vous avez deux possibilités: soit le dernier objet ajouté est supprimé (si vous venez de faire un ajout), soit la dernière duplication est supprimée (si vous venez de dupliquer des objets). Cette fonctionnalité est utilisée uniquement dans le cas d'un ajout ou d'une duplication."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto1":
            nomImageCourante = "Tuto23"
            image.image = #imageLiteral(resourceName: "Tuto23")
            text.text = "Merci d'avoir regardé ce tutoriel! Vous pouvez maintenant retourner à l'interface d'édition et commencez à éditer vos cartes."
            text.adjustsFontForContentSizeCategory = true
            break
        case "Tuto2":
            nomImageCourante = "Tuto1"
            image.image = #imageLiteral(resourceName: "Tuto1")
            text.text = "Bienvenue dans le tutoriel de WallE2. Vous allez maintenant apprendre à utiliser les différents outils et fonctionnalités de l'édition."
            text.adjustsFontForContentSizeCategory = true
            break
        default:
            break
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        enregistrementTuto()
        let gameViewController : GameViewController = segue.destination as! GameViewController;
        gameViewController.transitioningDelegate = self
        self.view.isHidden = true
        
    }
    
    func enregistrementTuto(){
        
        //let fileManager = FileManager.default
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        //print(documentDirectory)
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Tutoriel")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let nomXml = "/tuto.xml"
        
        self.tutoXmlPath = pathFileName + nomXml
        
        let sauvegarde = AEXMLDocument()
        let tuto = sauvegarde.addChild(name: "Tutoriel")
        
        let attributsVisionne = ["visionne" : "\(visionne)"]
        tuto.addChild(name: "DejaVu", attributes: attributsVisionne)
        
        let xmlString = sauvegarde.xml
        do {
            
            _ = try xmlString.write(toFile: self.tutoXmlPath, atomically: true, encoding: String.Encoding.utf8)
            
        }
        catch {
            print("\(error)")
        }
        
    }
   
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return animationController
    }

}
