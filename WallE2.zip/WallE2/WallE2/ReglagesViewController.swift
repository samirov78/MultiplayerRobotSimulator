//
//  ReglagesViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-04.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit
import AEXML

class Reglages {
    
    var couleurChoisie = ""
    var red : CGFloat = 0
    var blue : CGFloat = 0
    var green : CGFloat = 0
    var alpha: CGFloat = 0
    var son = true
    var presentation = ""
    
    init(){
        self.couleurChoisie = ""
        self.red = -0.098034
        self.blue = 0.838298
        self.green = 0.665049
        self.alpha = 1.0
        self.son = true
        self.presentation = "liste"
    }
    
    init(couleur: String, presentation: String, red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat, son: Bool){
        self.couleurChoisie = couleur
        self.presentation = presentation
        self.red = red
        self.blue = blue
        self.green = green
        self.alpha = alpha
        self.son = son
    }
    
}

class ReglagesViewController: UIViewController {
    @IBOutlet weak var Intensite: UISlider!
    @IBOutlet weak var Sonore: UISwitch!
    @IBOutlet weak var Bleu: UIButton!
    @IBOutlet weak var Rouge: UIButton!
    @IBOutlet weak var Vert: UIButton!
    @IBOutlet weak var Jaune: UIButton!
    @IBOutlet weak var Violet: UIButton!
    @IBOutlet weak var Rose: UIButton!
    
    @IBOutlet weak var Liste: UIButton!
    @IBOutlet weak var Grille: UIButton!
    @IBOutlet weak var Menu: UIButton!
    
    var couleurChoisie = ""
    var red : CGFloat = -0.098034
    var blue : CGFloat = 0.838298
    var green : CGFloat = 0.665049
    var alpha: CGFloat = 1.0
    var son = true
    var presentation = "liste"
    var reglageXmlPath = ""
    var parseurReglage = ParseurXmlReglages()
    
    
    
    
    @IBAction func BleuDown(_ sender: Any) {
        couleurChoisie = "bleu"
        //print(self.view.backgroundColor)
        //self.view.backgroundColor = UIColor.init(red: 0, green: 153, blue: 255, alpha: 1)
        self.view.backgroundColor = UIColor.init( red: -0.098034, green: 0.665049, blue:0.838298, alpha: alpha )
        red = -0.098034
        green = 0.665049
        blue = 0.838298
    }
    
    @IBAction func RougeDown(_ sender: Any) {
        couleurChoisie = "rouge"
        //print(self.view.backgroundColor)
        self.view.backgroundColor = UIColor.init( red: 0.561149, green: 0.055405, blue:0.00278461, alpha: alpha )
        red = 0.561149
        green = 0.055405
        blue = 0.00278461
    }
    
    @IBAction func VertDown(_ sender: Any) {
        couleurChoisie = "vert"
        //print(self.view.backgroundColor)
        self.view.backgroundColor = UIColor.init( red: 0.619195, green: 0.708972, blue:0.242016, alpha: alpha )
        red = 0.619195
        green = 0.708972
        blue = 0.242016
    }
    
    @IBAction func JauneDown(_ sender: Any) {
        couleurChoisie = "jaune"
        //print(self.view.backgroundColor)
        self.view.backgroundColor = UIColor.init( red: 0.912298, green: 0.663077, blue:0.158127, alpha: alpha )
        red = 0.912298
        green = 0.663077
        blue = 0.158127
    }
    
    @IBAction func RoseDown(_ sender: Any) {
        couleurChoisie = "rose"
        //print(self.view.backgroundColor)
        self.view.backgroundColor = UIColor.init( red: 0.88194, green: 0.51369, blue:0.510464, alpha: alpha )
        red = 0.88194
        green = 0.51369
        blue = 0.510464
    }
    
    
    @IBAction func VioletDown(_ sender: Any) {
        couleurChoisie = "violet"
        //print(self.view.backgroundColor)
        self.view.backgroundColor = UIColor.init( red: 0.741202, green: 0.471355, blue:0.824457, alpha: alpha )
        red = 0.741202
        green = 0.471355
        blue = 0.824457
    }
    
    @IBAction func IntensiteLumiere(_ sender: Any) {
        
        alpha = CGFloat(Intensite.value)
        self.view.backgroundColor = UIColor.init( red: red, green: green, blue: blue, alpha: alpha )
        
    }
    
    @IBAction func EffetsSonores(_ sender: Any) {
        
        son = Sonore.isOn
    }
    
    @IBAction func GrilleDown(_ sender: Any) {
        presentation = "grille"
        Grille.isEnabled = false
        Grille.alpha = 0.5
        Liste.isEnabled = true
        Liste.alpha = 1.0
        
    }
    
    @IBAction func ListeDown(_ sender: Any) {
        presentation = "liste"
        Liste.isEnabled = false
        Liste.alpha = 0.5
        Grille.isEnabled = true
        Grille.alpha = 1.0
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseurReglage.chargerXML()
        mettreAJourReglages()
        // Do any additional setup after loading the view, typically from a nib.
        Bleu.layer.cornerRadius = 10
        Rouge.layer.cornerRadius = 10
        Vert.layer.cornerRadius = 10
        Jaune.layer.cornerRadius = 10
        Violet.layer.cornerRadius = 10
        Rose.layer.cornerRadius = 10
        Menu.layer.cornerRadius = 10
        Grille.layer.cornerRadius = 10
        Liste.layer.cornerRadius = 10
        
        
    }
    
    func enregistrementReglages(){
        
        //let fileManager = FileManager.default
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        //print(documentDirectory)
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Reglages")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let nomXml = "/reglages.xml"
        
        self.reglageXmlPath = pathFileName + nomXml
        
        let sauvegarde = AEXMLDocument()
        let reglages = sauvegarde.addChild(name: "Reglages")
        
        let attributsCouleur = ["name" : "\(couleurChoisie)", "red" : "\(red)", "green" : "\(green)", "blue" : "\(blue)"]
        reglages.addChild(name: "Couleur", attributes: attributsCouleur)
        
        let attributSonore = ["son" : "\(son)"]
        reglages.addChild(name: "Effet", attributes: attributSonore)
        
        let attributPresentation = ["forme" : "\(presentation)"]
        reglages.addChild(name: "Presentation", attributes: attributPresentation)
        
        let attributLumiere = ["alpha" : "\(alpha)"]
        reglages.addChild(name: "Intensite", attributes: attributLumiere)
        
        let xmlString = sauvegarde.xml
        do {
            
            _ = try xmlString.write(toFile: self.reglageXmlPath, atomically: true, encoding: String.Encoding.utf8)
            
        }
        catch {
            print("\(error)")
        }
        
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
        red = parseurReglage.mesReglages.red
        blue = parseurReglage.mesReglages.blue
        green = parseurReglage.mesReglages.green
        alpha = parseurReglage.mesReglages.alpha
        Intensite.value = Float(alpha)
        son = parseurReglage.mesReglages.son
        presentation = parseurReglage.mesReglages.presentation
        couleurChoisie = parseurReglage.mesReglages.couleurChoisie
        if(presentation == "liste"){
            Liste.isEnabled = false
            Liste.alpha = 0.5
            Grille.isEnabled = true
            Grille.alpha = 1.0
        } else {
            Grille.isEnabled = false
            Grille.alpha = 0.5
            Liste.isEnabled = true
            Liste.alpha = 1.0
        }
        Sonore.isOn = son
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "retour") {
            enregistrementReglages()
            self.view.isHidden = true
            //print("estEnregistree")
            //print(reglageXmlPath)
        }
    }
}
