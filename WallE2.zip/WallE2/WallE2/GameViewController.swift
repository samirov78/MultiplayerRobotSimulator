//
//  GameViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-02-25.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    
    //private var game = GKScene(fileNamed: "GameScene")?.rootNode as! GameScene
    //private var game: GameScene?
    var nomCarte : String = ""
    var pathFichier : String = ""
    var sonActif = true
    var alphaReglage: CGFloat = 1.0
    var presentationListe = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //ButtonEdition.layer.cornerRadius = 10
        //ButtonStatistiques.layer.cornerRadius = 10
        // Load 'GameScene.sks' as a GKScene. This provides gameplay related content
        // including entities and graphs.
        
        if let scene = GKScene(fileNamed: "GameScene") {

            // Get the SKScene from the loaded GKScene
            if let sceneNode = scene.rootNode as! GameScene? {
                
                // Copy gameplay related content over to the scene
                sceneNode.entities = scene.entities
                sceneNode.graphs = scene.graphs
                sceneNode.nomCarte = nomCarte
                sceneNode.pathFichier = pathFichier
                sceneNode.sonActif = sonActif
                sceneNode.alphaReglage = alphaReglage
                sceneNode.presentationListe = presentationListe
                sceneNode.viewController = self
                // Set the scale mode to scale to fit the window
                sceneNode.scaleMode = .aspectFill
                //game = sceneNode
                // Present the scene
                if let view = self.view as! SKView? {
                    view.presentScene(sceneNode)
                    
                    view.ignoresSiblingOrder = true
                    
                    view.showsFPS = true
                    view.showsNodeCount = true
                    // game = sceneNode
                }
            }
        }
        
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    override func motionBegan(_ motion: UIEventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            print("heeeeeey")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.view.isHidden = true
    }
}
