//
//  Clavardage.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-07.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit
import Foundation
import SwiftSocket
import LocalAuthentication

class ClavardageViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var retourMenu: UIButton!
    // @IBOutlet weak var srvTxt: UILabel!
    @IBOutlet weak var utilisateurChoisi: UILabel!
    
    @IBOutlet weak var srvTxt: UITextField!
    
    @IBOutlet weak var txtPort: UITextField!
    
    @IBOutlet weak var txtPassWord: UITextField!
    @IBOutlet weak var txtLogin: UITextField!
    @IBOutlet weak var txtViewLog: UITextView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var envoyerBtn: UIButton!
    @IBOutlet weak var connectBtn: UIButton!
    
    @IBOutlet weak var disconnectBtn: UIButton!
    
    @IBOutlet weak var txtFieldMsg: UITextField!
    
    var login: String = ""
    var parseurReglage = ParseurXmlReglages()
    var motDePasse = ""
    var identifiant = ""
    var presenceTouchID = false
    //var touchID = TouchID()
    
    
    /*     @IBOutlet weak var tableViewUsersList: UITableView!
     */
    
    
    var client: TCPClient?
    var logTextVar : String? = ""
    var clientConnected : Bool = false //  variable pour montrer l etat de connectivite du client
    var connectedUsers : String = "" // variable qui va contenir la liste des utilisateurs connectes
    
    var TableView1 : [String : UITextView] = [:]
    var indexTableview = 0
    var currentChannel : String = ""
    var logs: [String: String] = [:]
    var lastUser : String = ""
    public var channelLists = [String]()
    var message : String = ""
    
    // @IBOutlet weak var TableViewConnectedList: UITableView!
    
    var indexarray = 0
    
    // TouchID
    // Référence: https://the-nerd.be/2015/10/01/authentication-with-touchid/
    
    func TouchID (){
        // 1. Create a authentication context
        let authenticationContext = LAContext()
        
        var error:NSError?
        
        // 2. Check if the device has a fingerprint sensor
        // If not, show the user an alert view and bail out!
        guard authenticationContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else {
            
            showAlertViewIfNoBiometricSensorHasBeenDetected()
            return
        }
        
        // 3. Check the fingerprint
        authenticationContext.evaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            localizedReason: "Laissez votre doigt appuyé sur le bouton 'Home'",
            reply: { [unowned self] (success, error) -> Void in
                
                if( success ) {
                    
                    // Fingerprint recognized
                    // Go to view controller
                    //self.navigateToAuthenticatedViewController()
                    //print("réussi")
                    /*self.motDePasse = "renardo"
                    self.identifiant = "momo"*/
                    //self.motDePasse = "samir"
                    //self.identifiant = "samir"
                     DispatchQueue.main.async { () -> Void in
                    self.txtLogin.text = self.identifiant
                    //self.txtLogin.
                    self.txtPassWord.text = self.motDePasse
                    }
                    
                }else {
                    
                    // Check if there is an error
                    if let error = error  {
                        let errorCode = (error as NSError).code
                        let message = self.errorMessageForLAErrorCode(errorCode: errorCode)
                        self.showAlertViewAfterEvaluatingPolicyWithMessage(message: message)
                        
                    }
                    
                }
                
        })

    }
    
    func showAlertViewAfterEvaluatingPolicyWithMessage( message:String ){
        
        showAlertWithTitle(title: "Error", message: message)
        
    }
    
    func showAlertViewIfNoBiometricSensorHasBeenDetected(){
            
        showAlertWithTitle(title: "Error", message: "This device does not have a TouchID sensor.")
            
    }
        
    func showAlertWithTitle( title:String, message:String ) {
            
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alertVC.addAction(okAction)
            
        DispatchQueue.main.async { () -> Void in
                
            self.present(alertVC, animated: true, completion: nil)
                
        }
            
    }
    
    /*func navigateToAuthenticatedViewController(){
        
        if let loggedInVC = storyboard?.instantiateViewController(withIdentifier: "LoggedInViewController") {
            
            DispatchQueue.main.async { () -> Void in
                
                navigationController?.pushViewController(loggedInVC, animated: true)
                
            }
            
        }
        
    }*/
    
    func errorMessageForLAErrorCode( errorCode:Int ) -> String{
        
        var message = ""
        
        switch errorCode {
            
        case LAError.appCancel.rawValue:
            message = "Authentication was cancelled by application"
            
        case LAError.authenticationFailed.rawValue:
            message = "The user failed to provide valid credentials"
            
        case LAError.invalidContext.rawValue:
            message = "The context is invalid"
            
        case LAError.passcodeNotSet.rawValue:
            message = "Passcode is not set on the device"
            
        case LAError.systemCancel.rawValue:
            message = "Authentication was cancelled by the system"
            
            
        case LAError.touchIDLockout.rawValue:
            message = "Too many failed attempts."
            
        case LAError.touchIDNotAvailable.rawValue:
            message = "TouchID is not available on the device"
            //message = "TouchID n'est pas disponible sur ce périphérique"
            
        case LAError.userCancel.rawValue:
            message = "The user did cancel"
            //message = "L'utilisateur a annulé"
            
        case LAError.userFallback.rawValue:
            message = "The user chose to use the fallback"
            //message = "L'utilisateur a choisi de revenir en arrière"
        default:
            message = "Did not find error code on LAError object"
            //message = "Erreur inconnue"
            
        }
        
        return message
        
    }
    
    // Fin
    

    
    //Se deconnecter du serveur
    @IBAction func disconnectToServeur(_ sender: Any) {
        
        if clientConnected == true      //cad boucle infinie tjrs active
        {
            client?.close()
            clientConnected = false
            print("you were disconnected")
            self.txtViewLog.text = self.txtViewLog.text.appending("\nVous avez été déconnecté du serveur")
            //txtViewConnectedList.text = ""
            //Ajout
            channelLists = []
            print ("disconnected channelLists = [] \(channelLists)")
            //self.tableView.reloadData()
        }
        else
        {
            print("Your are not connected to the server")
            let alert = UIAlertController(title: "Non connecté",
                                          message: "Vous n'êtes pas connecté au serveur",
                                          preferredStyle: UIAlertControllerStyle.alert)
            let submitAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(submitAction)
            present(alert, animated : true , completion : nil)
        }
    }
    
    
    //code execute apres avoir appuyer sur Entrer
    
    @IBAction func EnterPressed(_ sender: Any) {
        envoyerMsg(Any.self)
    }
    
    ///code execute apres avoir appuyer sur le bouton envoyer message
    @IBAction func envoyerMsg(_ sender: Any) {
        if txtFieldMsg.text != ""
        {
            if clientConnected
            {
                let date = Date()
                let formatter = DateFormatter()
                formatter.dateFormat = "HH:mm"
                let result = formatter.string(from: date)
                let dateConverted = result.addingPercentEncoding(withAllowedCharacters: NSCharacterSet .urlFragmentAllowed)
                
                
                //let msgCovertedToPerc = txtFieldMsg.text!.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed)
                
                //encode
                //let msgColonReplaced = msgCovertedToPerc?.replacingOccurrences(of: ";", with: "%3B")
                let msgEncode = Encode(data1: txtFieldMsg.text!)
                //print(msgCovertedToPerc!)
                //let sentStr = "1;"+msgColonReplaced!+";"+dateConverted!
                //  let desConvertedToPerc = connectedUsers
                // let message = "2;"+"0;"+msgColonReplaced!+";"+dateConverted!+";"+currentChannel
                
                let message = "2;"+"0;"+msgEncode+";"+dateConverted!+";"+currentChannel
                print(message)
                let msgByte = [UInt8](message.utf8)
                
                let taille = UInt32((message.lengthOfBytes(using: String.Encoding.utf8)))
                
                let tailleByte = self.toByteArray(taille)
                let toSend = tailleByte + msgByte
                
                client?.send(data: toSend ) // a gerer apres
                print ("tosend:" )
                print (toSend )
                txtFieldMsg.text = ""
                txtFieldMsg.becomeFirstResponder()
                
            }
            else
            {
                
                let alert = UIAlertController(title: "Non connecté",
                                              message: "Vous devez vous connecter pour envoyer un message",
                                              preferredStyle: UIAlertControllerStyle.alert)
                let submitAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(submitAction)
                present(alert, animated : true , completion : nil)
            }
            
        }
        else
        {
            print("Message vide")
            let alert = UIAlertController(title: "Message vide",
                                          message: "Vous ne pouvez pas envoyer un message vide",
                                          preferredStyle: UIAlertControllerStyle.alert)
            let submitAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(submitAction)
            present(alert, animated : true , completion : nil)
        }
    }
    
    
    
    ///code execute apres avoir appuyer sur le bouton se connecter
    
    @IBAction func connectToServer(_ sender: Any) {
        listenForIncomingMsg()
    }
    
    private func appendToLog(string: String) {
        //print(string)
        logTextVar! += "\n\(string)"
        
    }
    
    func listenForIncomingMsg() {
        if connectedUsers.range(of : txtLogin.text!) != nil
            // if utilisateursConnectes.range(of : txtLogin.text)!=nil
        {
            print("Ce nom d'utilisateur est déjà utilisé")
            let alert = UIAlertController(title: "login existant",
                                          message: "Ce nom d'utilisateur est déjà utilisé",
                                          preferredStyle: UIAlertControllerStyle.alert)
            let submitAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(submitAction)
            present(alert, animated : true , completion : nil)
        }
        else if clientConnected == true  //si le client est deja connecte
        {
            print("Your are already connected to the server")
            let alert = UIAlertController(title: "Déjà connecté",
                                          message: "Vous êtes déjà connecté au serveur",
                                          preferredStyle: UIAlertControllerStyle.alert)
            let submitAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(submitAction)
            present(alert, animated : true , completion : nil)
        }
        else //Dans le cas ou le client n etait pas connecte avant
        {
            DispatchQueue.global(qos: .background).async {
                let ServerAdress : String? = self.srvTxt.text
                let PortNumber : String? = self.txtPort.text
                self.login = self.txtLogin.text!
                let motDePasse : String? = self.txtPassWord.text
                print("Before TCPclient")
                self.client = TCPClient(address: ServerAdress!, port: Int32(PortNumber!)!)
                print("aFTER TCPclient")
                
                guard let client = self.client else { return }
                
                
                switch client.connect(timeout: 10) {
                    
                case .success:
                    print("Connected to host \(client.address)")
                    let message = "0;"+"0;"+self.login+";"+motDePasse!
                    let msgByte = [UInt8](message.utf8)
                    
                    let taille = UInt32((message.lengthOfBytes(using: String.Encoding.utf8)))
                    
                    let tailleByte = self.toByteArray(taille)
                    let toSend = tailleByte + msgByte
                    self.clientConnected = true
                    //print("tosend en byte")
                    // print (toSend)
                    
                    client.send(data: toSend)
                    
                    
                    //  client.send(string: "0;"+"0;"+login!+motDePasse!) //may be add control here later
                    
                    while (self.clientConnected == true) // boucler tant que le client est connecte
                    {
                        //  print ("renter ds while")
                        guard let data = client.read(1024*10) else { return }
                        print( "data")
                        print( data)
                        //let newData  = data[3 ... data.count-1]
                        //String.stringWithBytes(buff, encoding: NSUTF8StringEncoding)
                        
                        if let response = String(bytes: data, encoding: .utf8){
                            let index = response.index(response.startIndex, offsetBy: 4)
                            let newResponse = response.substring(from: index)
                            print ("response")
                            print (response)
                            print ("newresponse")
                            print (newResponse)
                            
                            
                            //   let commaSeparatedArray = response.characters.split(separator: ";")
                            //   .map(String.init)
                            let commaSeparatedArray = newResponse.components(separatedBy: ";")
                            let firstIndice : String = commaSeparatedArray[0]
                            let code : String = commaSeparatedArray[1]
                            //message de client LoggedInUser
                            print("firstIndice(" + firstIndice + ")")
                            //print(firstIndice)
                            print("code (" + code + ")")
                            
                            let message = "0;"+"2"
                            let msgByte = [UInt8](message.utf8)
                            
                            let taille = UInt32((message.lengthOfBytes(using: String.Encoding.utf8)))
                            
                            let tailleByte = self.toByteArray(taille)
                            let toSend = tailleByte + msgByte
                            
                            switch firstIndice {
                                
                            case "0":
                                
                                print ("entrer switch de connexion")
                                //print (response)
                                
                                switch code
                                {
                                    
                                case "0":
                                    //self.appendToLog(string: "Salut \(login!) tu es connecté maintenant.\n")
                                    print("tu es connecté mnt")
                                    client.send(data: toSend)
                                    //  client.send(string: "0;"+"2")
                                    //????
                                    // self.channelLists.append(login!)
                                    // self.tableView.reloadData()
                                    
                                    /*
                                     
                                     let boiteTexte2 = UITextView(frame:
                                     CGRect(x: 376, y: 481, width: 341, height: 310))
                                     
                                     
                                     boiteTexte2.textAlignment = NSTextAlignment.left
                                     boiteTexte2.backgroundColor = UIColor.white
                                     //boiteTexte2.editable = false
                                     boiteTexte2.isHidden = true
                                     self.view.addSubview(boiteTexte2)
                                     self.TableView1.append(boiteTexte2)
                                     
                                     
                                     
                                     
                                     */
                                    
                                    
                                    break
                                    
                                case "1":
                                    self.appendToLog(string: "\(commaSeparatedArray[2]) déjà connecté")
                                    //client.send(string: "0;"+"2")
                                    client.send(data: toSend)
                                    break
                                    
                                case "2" :
                                    print ("mot de passe incorrect")
                                    //client.close()
                                    self.clientConnected = false
                                    let alert = UIAlertController(title: "Alerte", message: "Login ou mot de passe incorrect", preferredStyle: UIAlertControllerStyle.alert)
                                    alert.addAction(UIAlertAction(title: "Réessayer", style: UIAlertActionStyle.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    break
                                    
                                case "3" :
                                    print ("iden incorrect")
                                    client.close()
                                    self.clientConnected = false
                                    let alert = UIAlertController(title: "Alerte", message: "Utilisateur déjà connecté", preferredStyle: UIAlertControllerStyle.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    break
                                    
                                case "4" :
                                    client.close()
                                    self.clientConnected = false
                                    let alert = UIAlertController(title: "Alerte", message: "Utilisateur déjà connecté", preferredStyle: UIAlertControllerStyle.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    break
                                    
                                case "5" :
                                    let alert = UIAlertController(title: "Non connecté",
                                                                  message: "Vous n'êtes pas connecté au serveur",
                                                                  preferredStyle: UIAlertControllerStyle.alert)
                                    let submitAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                                    alert.addAction(submitAction)
                                    self.present(alert, animated : true , completion : nil)
                                    
                                    break
                                    
                                case "6":
                                    self.appendToLog(string: "\(commaSeparatedArray[2]) vient de se conneter")
                                    //client.send(string: "0;"+"2")
                                    //client.send(data: toSend)
                                    //listeUsers += commaSeparatedArray[2].removingPercentEncoding!+"\n"
                                    //self.connectedUsers = listeUsers
                                    //print("connectedUsers ")
                                    let nom = commaSeparatedArray[2].removingPercentEncoding!
                                    //print("listUsers \(listeUsers)")
                                    self.channelLists.append(nom)
                                    print("channelLists \(self.channelLists)")
                                    
                                    //self.tableView.reloadData()
                                    self.logs[commaSeparatedArray[2]] = "\(commaSeparatedArray[2]) vient de se conneter\n"
                                    self.currentChannel = commaSeparatedArray[2]
                                    break
                                    
                                case "7":
                                    self.channelLists.remove(at: self.channelLists.index(of: commaSeparatedArray[2])!)
                                    //self.TableView1.remove(at: self.TableView1.
                                    self.appendToLog(string: "\(commaSeparatedArray[2]) vient de quitter")
                                    //client.send(string: "0;"+"2")
                                    //client.send(data: toSend)
                                    // enregistrement du text historique logtexts[commaSeparatedArray[2]]
                                    
                                    
                                    //  self.TableView1[commaSeparatedArray[2]]?.removeFromSuperview()
                                    
                                    //self.TableView1.removeValue(forKey: commaSeparatedArray[2])
                                    
                                    self.logs.removeValue(forKey:commaSeparatedArray[2])
                                    //let nom =channelLists[commaSeparatedArray[2]]
                                    //
                                    //self.channelLists.remove(at: commaSeparatedArray[2])
                                    /*self.channelLists.remove(at: self.channelLists.index(of: commaSeparatedArray[2])!)*/
                                    //self.tableView.reloadData()
                                    break
                                    /*case "1" : //Here a msg like aaa;;;;;; will crash down the app--> handle it()--> problem solved
                                     let msgConverted : String = commaSeparatedArray[2].removingPercentEncoding!
                                     let dateConverted : String = commaSeparatedArray[3].removingPercentEncoding!
                                     self.appendToLog(string: "\(commaSeparatedArray[1]) (\(dateConverted)) : \(msgConverted)")
                                     break*/
                                    
                                    
                                case "8" :
                                    print("entrer case 8")
                                    let numbreOfConnectedUsers  = commaSeparatedArray.count - 2
                                    
                                    //let  NbViewsToInsert = self.channelLists.count - self.TableView1.count
                                    if numbreOfConnectedUsers > 0
                                    {
                                        /*let boiteTexte2 = UITextView(frame:
                                         CGRect(x: 376, y: 481, width: 341, height: 310))
                                         boiteTexte2.textAlignment = NSTextAlignment.left
                                         boiteTexte2.backgroundColor = UIColor.red
                                         //boiteTexte2.editable = false
                                         //boiteTexte2.isHidden = true
                                         self.view.addSubview(boiteTexte2)
                                         self.TableView1.append(boiteTexte2)
                                         print(self.TableView1.count)*/
                                        
                                        
                                        print("nbUserConnected \(numbreOfConnectedUsers) ")
                                        var listeUsers = ""
                                        self.channelLists = []
                                        
                                        //self.tableView.reloadData()
                                        for i in 2...numbreOfConnectedUsers+1
                                        { // self.channelLists = []
                                            print("boucle for entree")
                                            //var nom = ""
                                            listeUsers += commaSeparatedArray[i].removingPercentEncoding!+"\n"
                                            self.connectedUsers = listeUsers
                                            print("connectedUsers ")
                                            let nom = commaSeparatedArray[i].removingPercentEncoding!
                                            print("listUsers \(listeUsers)")
                                            //if (listeUsers != "" ){
                                            self.channelLists.append(nom)
                                            print("channelLists \(self.channelLists)")
                                            
                                            //self.tableView.reloadData()
                                            // print ("self.tableView0\(self.tableView)")
                                            
                                            //modification
                                            //if (self.channelLists.count > self.TableView1.count){
                                            //let  NbViewsToInsert = self.channelLists.count - self.TableView1.count
                                            
                                            
                                            //for i in 1...NbViewsToInsert  {
                                            // let boiteTexte2 = UITextView(frame: CGRectMake(32, 181.0, 772.0, 443.0))
                                            // boiteTexte2
                                            self.logs[commaSeparatedArray[i]] = "" //chaine
                                            //}
                                            
                                        }
                                        if self.channelLists.count > 0
                                        {
                                            self.currentChannel = self.channelLists[0]
                                        }
                                        //self.lastUser = commaSeparatedArray[i]
                                        
                                        //}
                                    }
                                    
                                    
                                    //self.tableView.reloadData()
                                    
                                    break
                                    
                                default : print ("fin switch")
                                    break
                                }
                                
                                // end of switch code 0
                                break
                                
                            // cas de chat
                            case "2" :
                                
                                print ("entrer switch de connexion")
                                
                                switch code
                                {
                                    
                                case "0" : //Here a msg like aaa;;;;;; will crash down the app--> handle it()--> problem solved
                                    //self.view.bringSubview(toFront: self.TableView1[commaSeparatedArray[2]]!)
                                    
                                    //let tailleByte = self.toByteArray(taille)
                                    let msgConverted : String = commaSeparatedArray[3]
                                    
                                    let message = self.Decode(data1: msgConverted)
                                    
                                    //let msgConverted = Decode(data: commaSeparatedArray[3])
                                    let dateConverted : String = commaSeparatedArray[4]
                                    //self.appendToLog(string: "\(commaSeparatedArray[2]) (\(dateConverted)) : \(msgConverted) ")
                                    print("message recu : "+msgConverted)
                                    var current = commaSeparatedArray[2]
                                    if(self.login == commaSeparatedArray[2]){
                                        current = commaSeparatedArray[5]
                                    }
                                    self.logs[current]?.append( commaSeparatedArray[2] + ":"+message + "\n")
                                    
                                    //self.logs[current]?.append( commaSeparatedArray[2] + ":"+commaSeparatedArray[3] + "\n")
                                    
                                    //  self.TableView1[self.indexarray].text = "\(commaSeparatedArray[2]) (\(dateConverted)) : \(msgConverted) "
                                    print ("emmeteur: (" + commaSeparatedArray[2] + ")")
                                    
                                    
                                    //     if self.indexarray == 0 {self.indexarray = 1} else {self.indexarray = 0}
                                    //self.TableView1[commaSeparatedArray[2]]?.isUserInteractionEnabled = true
                                    break
                                    //\(commaSeparatedArray[5])
                                    
                                default :
                                    break
                                }// fin switch code 2
                                
                                break
                                
                            default : break
                                
                            } // end  of switch firstIndice
                        }//end if
                        
                        DispatchQueue.main.async {
                            //refresh the viewself
                            if self.logs[self.currentChannel] != nil
                            {
                                print ("currentchennel : "+self.currentChannel)
                                self.txtViewLog.text = self.logs[self.currentChannel]!
                                self.utilisateurChoisi.text = self.currentChannel
                                //print ("testtt:"+(self.logs[self.currentChannel]?)!)
                            }
                            
                            
                            self.tableView.reloadData()
                        }
                    }//end while
                    break
                case .failure(let error):
                    self.clientConnected = false
                    print(error)
                    
                } //end switch client connect
                
            }
        }

    }
    
    //ajout
    
    func toByteArray<T>(_ value: T) -> [UInt8]{
        var value = value
        return withUnsafePointer(to: &value) {
            $0.withMemoryRebound(to: UInt8.self, capacity: MemoryLayout<T>.size) {
                Array(UnsafeBufferPointer(start: $0, count: MemoryLayout<T>.size))
            }
        }
    }
    
    func Encode(data1: String) -> String {
        
        data1.replacingOccurrences(of: "%s", with: "%%s")
        
        return data1.replacingOccurrences(of: ";", with: "%s")
    }
    
    func Decode(data1: String) -> String {
        
        var dataArray : [Character] = []
        dataArray = Array(data1.characters)
        var result : String = ""
        var i = 0
        while i < dataArray.count
        {
            
            if i == dataArray.count-1 || dataArray[i] != "%" || dataArray[i + 1] != "s"
            {
                result.append(dataArray[i])
                //result += dataArray[i]
            }
            else if i == 0 || dataArray[i - 1] != "%"
            {
                result += ";"
                i = i+1
            }
            i = i+1
        }
        return result
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseurReglage.chargerXML()
        mettreAJourReglages()
        // Do any additional setup after loading the view.
        retourMenu.layer.cornerRadius = 10
        disconnectBtn.layer.cornerRadius = 10
        connectBtn.layer.cornerRadius = 10
        envoyerBtn.layer.cornerRadius = 10
        
        tableView.delegate = self
        tableView.dataSource = self
        //parseurID.chargerXML()
        //print("presence: ", presenceTouchID)
       
        if(presenceTouchID){
            TouchID()
            
        }
        //touchID.interface = "clavardage"
        
            
        //TouchID()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.view.isHidden = true
    }
    
    //tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return channelLists.count
        //return tableau.count
    }
    
    //tableView
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
    //tableView
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            channelLists.remove(at: indexPath.row)
            //self.tableView.reloadData()
        }
    }
    
    //tableView
    func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let item = channelLists[indexPath.row]
        // let item = tableau[indexPath.row]
        cell.textLabel?.text = item
        return cell
    }
    
    //tableView
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // tableView.deselectRow(at: indexPath as IndexPath, animated: true)
        envoyerBtn.isHidden = false
        txtFieldMsg.isHidden = false
        //showAllEmo.hidden = false
        let indexTableview = indexPath.row
        
        // currentChannel = channelLists[indexTableview]
        
        
        //view.bringSubview(toFront: TableView1[currentChannel]!)
        //self.TableView1[currentChannel]?.isUserInteractionEnabled = truea
        
        if self.logs[channelLists[indexTableview]] != nil
        {
            currentChannel = channelLists[indexTableview]
            utilisateurChoisi.text = currentChannel
            self.txtViewLog.text = self.logs[self.currentChannel]!
        }
        
        
    }
    
    
}


