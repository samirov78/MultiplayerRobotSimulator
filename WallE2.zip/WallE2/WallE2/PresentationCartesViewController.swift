//
//  PresentationCartesViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-03-26.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit

class CarteEnregistree{
    
    var image = UIImage(named : "")
    var nomCarte: String = ""
    
    init(nom: String, image: UIImage){
        self.nomCarte = nom
        self.image = image
    }
    
    init(nom: String){
        self.nomCarte = nom
    }
    
}

class PresentationCartesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIViewControllerTransitioningDelegate  {
    
    @IBOutlet weak var notationBnt: UIButton!
    @IBOutlet weak var ButtonNouvTuto: UIButton!
    @IBOutlet weak var aleatoire: UIButton!
    @IBOutlet weak var carteChoisieLabel: UILabel!
    @IBOutlet weak var ButtonNouvelleCarte: UIButton!
    
    @IBOutlet weak var ButtonCarteSelectionnee: UIButton!

    @IBOutlet weak var retourMenu: UIButton!
    var parseur = ParseurXml()
    var parseurReglage = ParseurXmlReglages()
    var fichierChoisi: String!
    var documentDirectory : NSString!
    @IBOutlet weak var tableView: UITableView!
    
    
    @IBOutlet weak var imageView: UIImageView!
    var tabViewElement = [String]()
    var fichiersDansDossier = [String]()
    var tableau = ["Bonjour", "Hello", "Salut"]
    var image = UIImage(named : "")
    var cartesDansDossier = [CarteEnregistree]()
    var carteChoisie : String = ""
    var boutonCarteColor : UIColor!
    
    // Effet de transition
    let animationController = AnimationController()
    
    // Variables pour tutoriel
    var parseurTuto = TutoXmlParseur()
    var dejaVu = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseurReglage.chargerXML()
        mettreAJourReglages()
        parseurTuto.chargerXML()
        dejaVu = parseurTuto.dejaVu
        // Do any additional setup after loading the view, typically from a nib.
        notationBnt.layer.cornerRadius = 10
        ButtonNouvTuto.layer.cornerRadius = 10
        aleatoire.layer.cornerRadius = 10
        retourMenu.layer.cornerRadius = 10
        ButtonNouvelleCarte.layer.cornerRadius = 10
        ButtonCarteSelectionnee.layer.cornerRadius = 10
        ButtonCarteSelectionnee.isEnabled = false
        boutonCarteColor = ButtonCarteSelectionnee.backgroundColor
        //ButtonCarteSelectionnee.backgroundColor = UIColor.lightGray
        ButtonCarteSelectionnee.alpha = 0.5
        notationBnt.isEnabled = false
        //notationBnt.alpha = 0.5
        notationBnt.isHidden = true
        tableView.delegate = self
        tableView.dataSource = self
        chargerDossier()
        if(dejaVu){
            ButtonNouvelleCarte.isEnabled = true
            ButtonNouvelleCarte.isHidden = false
            ButtonNouvTuto.isEnabled = false
            ButtonNouvTuto.isHidden = true
        } else {
            ButtonNouvelleCarte.isEnabled = false
            ButtonNouvelleCarte.isHidden = true
            ButtonNouvTuto.isHidden = false
            ButtonNouvTuto.isEnabled = true
        }
        if(fichiersDansDossier.isEmpty){
            aleatoire.isEnabled = false
            //aleatoire.backgroundColor = UIColor.lightGray
            aleatoire.alpha = 0.5
        }
        /*for fichier in fichiersDansDossier {
            
        }*/
        //print("Fichier dans dossier: ", fichiersDansDossier)
        //self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        //imageView = UIImageView(image: image!)
        //imageView.image = image
        //imageView.isHidden = false
        //self.view.addSubview(imageView)
        //print("l'image: ", image?.description)
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func chargerDossier(){
        let fileManager = FileManager.default
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        documentDirectory = path.first! as NSString
        //print("doc dir: ", documentDirectory)
        let pathFileName = documentDirectory.appendingPathComponent("Cartes")
        print("path: ", pathFileName)
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        let enumerator:FileManager.DirectoryEnumerator = fileManager.enumerator(atPath: (documentDirectory as String) + "/Cartes")!
        
        
        while let nomfichier = enumerator.nextObject() as? String {
            //print ("nom fichier: ", nomfichier)
            if nomfichier.hasSuffix("xml") {
                //tableau.append(nomfichier)
                fichiersDansDossier.append(nomfichier.replacingOccurrences(of: ".xml", with: "") )
                //cartesDansDossier.append(CarteEnregistree(nom: nomfichier.replacingOccurrences(of: ".xml", with: "") ))
            }
            if nomfichier.hasSuffix("png") {
                
                image = chargerImage(path: (documentDirectory as String) + "/Cartes/" + nomfichier)
                cartesDansDossier.append(CarteEnregistree(nom: nomfichier.replacingOccurrences(of: ".png", with: ""), image: image! ))
                /*for carte in cartesDansDossier {
                    if(carte.nomCarte == nomfichier.replacingOccurrences(of: ".xml", with: "")){
                        print("ici")
                        carte.image = image
                    }
                }*/
            }
        }
    }
    
    func chargerImage(path: String) -> UIImage? {
        
        image = UIImage(contentsOfFile: path)
        
        /*if image == nil {
            
            print("missing image at: \(path)")
        }*/
        //print("le path", "\(path)")
        
        return image
        
    }
    
    //Tableview Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return fichiersDansDossier.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //print("hello")
            
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let fileName = fichiersDansDossier[indexPath.row]
        //let fileName = tableau[indexPath.row]
        cell.textLabel?.text = fileName
        //cell.detailTextLabel?.text = "Delicious!"
        //cell.imageView?.image = UIImage(named: fruitName)
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath as IndexPath, animated: true)
        ButtonCarteSelectionnee.isEnabled = true
        ButtonCarteSelectionnee.alpha = 1.0
        //ButtonCarteSelectionnee.backgroundColor = boutonCarteColor
        notationBnt.isEnabled = true
        //notationBnt.backgroundColor = boutonCarteColor
        //notationBnt.alpha = 1.0
        notationBnt.isHidden = false
        let row = indexPath.row
        carteChoisie = fichiersDansDossier[row]
        carteChoisieLabel.text = carteChoisie
        for carte in cartesDansDossier {
            if(carteChoisie == carte.nomCarte){
                //print("dedans")
                imageView.image = carte.image
                //self.view.addSubview(imageView)
            }
        }
        //print(fichiersDansDossier[row])
    }
   
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    ///prepare a envoyer la carte au mode editeur
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "carteEnregistree") {
            let gameViewController : GameViewController = segue.destination as! GameViewController;
            gameViewController.sonActif = parseurReglage.mesReglages.son
            gameViewController.presentationListe = true
            gameViewController.alphaReglage = parseurReglage.mesReglages.alpha
            gameViewController.nomCarte = carteChoisie
            gameViewController.pathFichier = (documentDirectory as String) + "/Cartes/"
            gameViewController.transitioningDelegate = self
        }
        
        if(segue.identifier == "nouvelleCarte"){
            let gameViewController : GameViewController = segue.destination as! GameViewController;
            gameViewController.alphaReglage = parseurReglage.mesReglages.alpha
            gameViewController.presentationListe = true
            gameViewController.sonActif = parseurReglage.mesReglages.son
            gameViewController.transitioningDelegate = self
        }
        
        if(segue.identifier == "aleatoire"){
            let gameViewController : GameViewController = segue.destination as! GameViewController;
            let randomIndex = Int(arc4random_uniform(UInt32(fichiersDansDossier.count)))
            carteChoisie = fichiersDansDossier[randomIndex]
            gameViewController.sonActif = parseurReglage.mesReglages.son
            gameViewController.alphaReglage = parseurReglage.mesReglages.alpha
            gameViewController.presentationListe = true
            gameViewController.nomCarte = carteChoisie
            gameViewController.pathFichier = (documentDirectory as String) + "/Cartes/"
            gameViewController.transitioningDelegate = self
        }
        
        if(segue.identifier == "note"){
            let notationViewController : NotationViewController = segue.destination as! NotationViewController;
            notationViewController.nomCarte = carteChoisie
            notationViewController.presentation = "liste"
            notationViewController.image = imageView.image
            notationViewController.pathFichier = (documentDirectory as String) + "/Cartes/"
            
        }
        
        self.view.isHidden = true
    }
    
    /* func animationControllerForPresentedController(presented: UIViewController, presentingController presenting: UIViewController, sourceController source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
    }*/
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return animationController
    }
    
}
