//
//  AstucesViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-11.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation
import UIKit

class AstucesViewController: UIViewController {
    @IBOutlet weak var textAstuces: UITextView!
    @IBOutlet weak var imageAstuces: UIImageView!
    @IBOutlet weak var right: UIButton!
    var nomImageCourante = "astuce0"
    
    @IBOutlet weak var menu: UIButton!
    
    @IBOutlet weak var left: UIButton!
    var parseurReglage = ParseurXmlReglages()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menu.layer.cornerRadius = 10
        left.layer.cornerRadius = 10
        right.layer.cornerRadius = 10
        // Do any additional setup after loading the view, typically from a nib.
        parseurReglage.chargerXML()
        mettreAJourReglages()
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.view.isHidden = true
    }
    
    @IBAction func goLeft(_ sender: Any) {
        switch(nomImageCourante){
        case "astuce2":
            nomImageCourante = "astuce1"
            imageAstuces.image = #imageLiteral(resourceName: "astuce1")
            textAstuces.text = "Si vous ne savez pas éditer une carte surtout ne vous inquiétez pas! Vous avez la possibilité de visionner à nouveau le tutoriel de l'éditeur à partir de l'interface d'édition."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce3":
            nomImageCourante = "astuce2"
            imageAstuces.image = #imageLiteral(resourceName: "astuce2")
            textAstuces.text = "Vous n'aimez les couleurs et la luminosité de l'application? Pas de problèmes! Il vous suffit de les changer à partir de l'interface de réglages."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce4":
            nomImageCourante = "astuce3"
            imageAstuces.image = #imageLiteral(resourceName: "astuce3")
            textAstuces.text = "Bon ok nous sommes d'accord, les bruits pendant l'édition c'est drôle au début mais à la longue on s'en lasse un peu. Si vous êtes dérangez par les effets sonores il vous suffit de les désactiver grâce à l'interface de réglages."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce5":
            nomImageCourante = "astuce4"
            imageAstuces.image = #imageLiteral(resourceName: "astuce4")
            textAstuces.text = "Vous êtes l'heureux propriétaire de cet iPad? Quelle chance! Si vous avez déjà un profil, vous n'avez pas besoin de rentrer un mot de passe ou un identifiant pour vous connecter au clavardage. Vous pouvez simplement utiliser le Touch ID. Lorsque vous appuyez sur le bouton Clavardage, laissez votre doigt appuyé, l'application s'occupe du reste."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce0":
            nomImageCourante = "astuce5"
            imageAstuces.image = #imageLiteral(resourceName: "astuce5")
            textAstuces.text = "Si vous n'avez pas encore de profil prenez quelques minutes pour en créer un en cliquant sur le bouton Creation Profil du menu d'accueil. Vous ne pouvez pas utiliser les fonctionnalités du clavardage sans profil."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce1":
            nomImageCourante = "astuce0"
            imageAstuces.image = #imageLiteral(resourceName: "astuce0")
            textAstuces.text = "Bienvenue dans le monde des astuces de WallE2!!! Pour commencer à visionner les astuces cliquez sur la flèche en bas à droite."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        default:
            break
        }

    }
    
    @IBAction func goRight(_ sender: Any) {
        switch(nomImageCourante){
        case "astuce0":
            nomImageCourante = "astuce1"
            imageAstuces.image = #imageLiteral(resourceName: "astuce1")
            textAstuces.text = "Si vous ne savez pas éditer une carte surtout ne vous inquiétez pas! Vous avez la possibilité de visionner à nouveau le tutoriel de l'éditeur à partir de l'interface d'édition."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce1":
            nomImageCourante = "astuce2"
            imageAstuces.image = #imageLiteral(resourceName: "astuce2")
            textAstuces.text = "Vous n'aimez les couleurs et la luminosité de l'application? Pas de problèmes! Il vous suffit de les changer à partir de l'interface de réglages."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce2":
            nomImageCourante = "astuce3"
            imageAstuces.image = #imageLiteral(resourceName: "astuce3")
            textAstuces.text = "Bon ok nous sommes d'accord, les bruits pendant l'édition c'est drôle au début mais à la longue on s'en lasse un peu. Si vous êtes dérangez par les effets sonores il vous suffit de les désactiver grâce à l'interface de réglages."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce3":
            nomImageCourante = "astuce4"
            imageAstuces.image = #imageLiteral(resourceName: "astuce4")
            textAstuces.text = "Vous êtes l'heureux propriétaire de cet iPad? Quelle chance! Vous n'avez pas besoin de rentrer un mot de passe ou un idantifiant pour vous connecter au clavardage. Vous pouvez simplement utiliser le Touch ID. Lorsque vous appuyez sur le bouton Clavardage, laissez votre doigt appuyé, l'application s'occupe du reste."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce4":
            nomImageCourante = "astuce5"
            imageAstuces.image = #imageLiteral(resourceName: "astuce5")
            textAstuces.text = "Si vous n'avez pas encore de profil prenez quelques minutes pour en créer un en cliquant sur le bouton Creation Profil du menu d'accueil. Vous ne pouvez pas utiliser les fonctionnalités du clavardage sans profil."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        case "astuce5":
            nomImageCourante = "astuce0"
            imageAstuces.image = #imageLiteral(resourceName: "astuce0")
            textAstuces.text = "Bienvenue dans le monde des astuces de WallE2!!! Pour commencer à visionner les astuces cliquez sur la flèche en bas à droite."
            textAstuces.adjustsFontForContentSizeCategory = true
            break
        default:
            break
        }

    }
    
    
}
