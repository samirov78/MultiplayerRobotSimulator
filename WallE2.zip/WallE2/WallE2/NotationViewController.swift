//
//  NotationViewController.swift
//  WallE2
//
//  Created by Morgane Renard on 17-04-11.
//  Copyright © 2017 Morgane Renard. All rights reserved.
//

import Foundation

import UIKit

import AEXML

class NotationViewController: UIViewController {
    

    @IBOutlet weak var enregistrerGrille: UIButton!
    @IBOutlet weak var nomCarteLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var ratingControl: RatingControl!
    var parseurReglage = ParseurXmlReglages()
    var parseurNotation = NotationXmlParseur()
    var nomCarte = ""
    var image = UIImage(named : "")
    var pathFichier = ""
    var noteXmlPath = ""
    var presentation = "liste"
    
    @IBOutlet weak var annulerGrille: UIButton!
    @IBOutlet weak var enregistrer: UIButton!
    @IBOutlet weak var annuler: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        parseurReglage.chargerXML()
        mettreAJourReglages()
        annuler.layer.cornerRadius = 10
        annulerGrille.layer.cornerRadius = 10
        enregistrer.layer.cornerRadius = 10
        enregistrerGrille.layer.cornerRadius = 10
        nomCarteLabel.text = nomCarte
        imageView.image = image
        parseurNotation.chargerXML(nomFichier: nomCarte)
        //note = parseurNotation.note
        mettreAJourNote()
        if(presentation == "grille"){
            enregistrerGrille.isHidden = false
            enregistrerGrille.isEnabled = true
            enregistrer.isHidden = true
            enregistrer.isEnabled = false
            annulerGrille.isHidden = false
            annulerGrille.isEnabled = true
            annuler.isHidden = true
            annuler.isEnabled = false
        } else {
            enregistrerGrille.isHidden = true
            enregistrerGrille.isEnabled = false
            enregistrer.isHidden = false
            enregistrer.isEnabled = true
            annulerGrille.isHidden = true
            annulerGrille.isEnabled = false
            annuler.isHidden = false
            annuler.isEnabled = true
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /// mise à jour les réglages
    func mettreAJourReglages(){
        self.view.backgroundColor = UIColor.init(red: parseurReglage.mesReglages.red, green: parseurReglage.mesReglages.green, blue: parseurReglage.mesReglages.blue, alpha: parseurReglage.mesReglages.alpha)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "enregistrer"){
            //print(ratingControl.nbStar)
            enregistrerNote()
        }
        if(segue.identifier == "enregistrerGrille"){
            enregistrerNote()
        }
        self.view.isHidden = true
    }
    
    func enregistrerNote(){
        //let fileManager = FileManager.default
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        //print(documentDirectory)
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Notation")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let nomXml = "/" + nomCarte + "note.xml"
        
        self.noteXmlPath = pathFileName + nomXml
        
        let sauvegarde = AEXMLDocument()
        let note = sauvegarde.addChild(name: "Cartes")
        
        let attributsVisionne = ["nom" : "\(nomCarte)", "note" : "\(ratingControl.rating)"]
        note.addChild(name: "Notation", attributes: attributsVisionne)
        
        let xmlString = sauvegarde.xml
        do {
            
            _ = try xmlString.write(toFile: self.noteXmlPath, atomically: true, encoding: String.Encoding.utf8)
            
        }
        catch {
            print("\(error)")
        }
    }
    
    func mettreAJourNote(){
        switch(parseurNotation.note){
            case "0":
                ratingControl.rating = 0
            break
            case "1":
                ratingControl.rating = 1
            break
            case "2":
                ratingControl.rating = 2
            break
            case "3":
                ratingControl.rating = 3
            break
            case "4":
                ratingControl.rating = 4
            break
            case "5":
                ratingControl.rating = 5
            break
            default:
            break
        }
    }
    
}

class NotationXmlParseur :NSObject, XMLParserDelegate, FileManagerDelegate {
    
    var parseurXml = XMLParser()
    
    var nomCarte = ""
    var note = ""
    
    func chargerXML(nomFichier: String){
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentDirectory = path.first! as NSString
        
        // Dossier créé pour les cartes (xml et images)
        let pathFileName = documentDirectory.appendingPathComponent("Notation")
        
        var erreur: NSError?
        do {
            try FileManager.default.createDirectory(atPath: pathFileName, withIntermediateDirectories: false, attributes: nil)
        } catch let erreur as NSError {
            print(erreur.localizedDescription);
        }
        
        let pathCourant = documentDirectory.appendingPathComponent("/Notation/" + nomFichier + "note.xml")
        print(pathCourant)
        let fileManager = FileManager.default
        
        if fileManager.fileExists(atPath: pathCourant){
            var dataBuffer = fileManager.contents(atPath: pathCourant)
            dataBuffer = NSData(contentsOfFile: pathCourant) as Data?
            
            self.parseurXml = XMLParser(data: dataBuffer!)
            self.parseurXml.delegate = self
            self.parseurXml.parse()
            
            
        }else{
            print("file not found")
        }
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        switch elementName {
            
        case "Cartes":
            
            break
            
        case "Notation":
            
            nomCarte = attributeDict["nom"] as String!
            note = attributeDict["note"] as String!
            
            break
            
        default:
            
            break
            
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?){
        
        
    }
    
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Parseur XML : Une erreur est survenue")
    }
}


